# FONT Studio 4 — final review notes

This is an automated-test and manual source review record, not an external security audit or Android device test.

## Issue addressed

The v3 importer returned `mode=original` for ordinary fonts; UI gating disabled editing and the final bytes path copied the original. The first v4 contract test failed on that exact behavior. v4 imports normal outline fonts into an editable mode and runs an actual generic editor before FontFace loading and APK generation. Only source bytes chosen by the user at runtime are processed.

## New paths checked

- TTF composite outlines, CFF and CFF2 paths are decoded with a local fontkit bundle. Cubics are reduced to quadratics with a small control-deviation bound. Glyph IDs/cmap remain stable when output becomes static TrueType.
- General geometry and tracking change glyph coordinates and hmtx, not just canvas transforms.
- Static thickness uses bounded contour-normal offsets; native variable weight uses the source axis. Synthetic offsets are intentionally described as geometric, not the font designer's optical weight masters.
- Variable CFF left side bearings cannot be copied from default hmtx after interpolation: output lsb uses the edited outline xmin. Variable TrueType origin handling and reused composite contour caching were also corrected and covered by separate gvar coordinate checks.
- Ordinary GSUB is retained. General leading-zero insertion remains disabled rather than destroying arbitrary source GSUB. OPPO's previous implementation remains intact and has a dedicated 5,778-string regression suite.
- Preview FontFace and generated font bytes are identical in real-browser TTF and OPPO workflows.
- User names flow to filename, Android app label, Samsung font XML and internal font names; package IDs remain safe hashes. Both source namespaces and native bridge identify v4, not v3.
- Approved icon is a real resource in both helper and output packages. No network dependencies, bundled fonts, source APK classes, permissions or private signing keys are shipped.

## Deliberate limits

- No physical Android/Samsung or APK-install test; browser tests exercise genuine parsing/rendering/building but intercept the native save call.
- No antivirus or Play Protect safety certification. Signature/math verification is not a guarantee that a phone's security policy permits installation.
- Dedicated v4 helper and generated-font package namespace avoids signing-key conflicts with v3. Previous per-device keys are not migrated.
- WOFF/WOFF2, bitmap/color glyphs and variable FeatureVariations are rejected with an explanation. Advanced vertical, math, hint and some optical-layout support is outside this local editor's scope.
- Excessive negative tracking or large geometry can be invalid and is rejected. Extreme synthetic weight can close small counters or damage delicate strokes; the UI explains this.
- fontkit is a third-party parser, not a proof of correctness for every font variant. The support claim is for the tested outline formats with explicit errors for unsupported/corrupt files, not every font ever produced.

See `checks/` for actual fresh build, cryptographic, name, pixel and layout test results. Local test font fixtures, generated font packages and signing secrets are intentionally excluded from delivery.
