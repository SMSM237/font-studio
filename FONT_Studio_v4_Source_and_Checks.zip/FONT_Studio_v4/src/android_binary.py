"""Small binary XML/DEX assembler for the font-free Android document bridge.
Only statically defined classes and Android framework APIs are used.
"""
import struct,hashlib,zlib,json
from pathlib import Path
P16=lambda v:struct.pack('<H',v&65535)
P32=lambda v:struct.pack('<I',v&0xffffffff)
NONE=0xffffffff
ANDROID='http://schemas.android.com/apk/res/android'
ATTR={'label':0x01010001,'icon':0x01010002,'name':0x01010003,'hasCode':0x0101000c,'configChanges':0x0101001f,'debuggable':0x0101000f,'exported':0x01010010,'minSdkVersion':0x0101020c,'versionCode':0x0101021b,'versionName':0x0101021c,'targetSdkVersion':0x01010270,'allowBackup':0x01010280}
def chunk(t,p,header=8):return struct.pack('<HHI',t,header,len(p)+8)+p

def manifest(package,label,activity=None,target=35,version_code=1,version_name="1.0",icon=None):
    ns=[('manifest', [('package',package),('versionCode',version_code),('versionName',version_name)], [
        ('uses-sdk',[('minSdkVersion',26),('targetSdkVersion',target)],[]),
        ('application',[('label',label),('hasCode',bool(activity)),('debuggable',False),('allowBackup',False)]+([('icon',{'resource':icon})] if icon is not None else []),
            [('activity',[('name',activity),('exported',True),('configChanges',0x4a0)],[('intent-filter',[],[
                ('action',[('name','android.intent.action.MAIN')],[]),
                ('category',[('name','android.intent.category.LAUNCHER')],[])])])] if activity else [])])]
    strings=['android',ANDROID]
    def add(s):
        if s not in strings:strings.append(s)
    def visit(node):
        tag,attrs,children=node;add(tag)
        for key,val in attrs:
            add(key)
            if isinstance(val,str):add(val)
        for child in children:visit(child)
    visit(ns[0]);idx={s:i for i,s in enumerate(strings)}
    blob=bytearray();offsets=[]
    for s in strings:
        b=s.encode('utf-16le');offsets.append(len(blob));blob+=P16(len(b)//2)+b+b'\0\0'
    while len(blob)%4:blob.append(0)
    pool=chunk(1,P32(len(strings))+P32(0)+P32(0)+P32(28+len(strings)*4)+P32(0)+b''.join(P32(o)for o in offsets)+blob,28)
    rm=chunk(0x180,b''.join(P32(ATTR.get(s,0))for s in strings))
    def xmlnode(t,data):return chunk(t,P32(1)+P32(NONE)+data,16)
    def emit(node):
        tag,attrs,children=node
        # Android sorts resource-mapped attributes by ID; unnamespaced fields last.
        attrs=sorted(attrs,key=lambda x:ATTR.get(x[0],0xffffffff))
        ab=bytearray()
        for k,v in attrs:
            n=idx[ANDROID] if k!='package' else NONE
            if isinstance(v,bool):typ,val,raw=0x12,(0xffffffff if v else 0),NONE
            elif isinstance(v,int):typ,val,raw=0x10,v,NONE
            elif isinstance(v,dict):typ,val,raw=1,v['resource'],NONE
            else:typ,val,raw=3,idx[v],idx[v]
            ab+=P32(n)+P32(idx[k])+P32(raw)+P16(8)+bytes([0,typ])+P32(val)
        start=xmlnode(0x102,P32(NONE)+P32(idx[tag])+struct.pack('<6H',20,20,len(attrs),0,0,0)+ab)
        return start+b''.join(emit(c)for c in children)+xmlnode(0x103,P32(NONE)+P32(idx[tag]))
    data=pool+rm+xmlnode(0x100,P32(idx['android'])+P32(idx[ANDROID]))+emit(ns[0])+xmlnode(0x101,P32(idx['android'])+P32(idx[ANDROID]))
    return chunk(3,data)

def decode_manifest(raw):
    import xml.etree.ElementTree as ET
    p=8;strings=[];root=None;stack=[]
    while p<len(raw):
        t,hs,size=struct.unpack_from('<HHI',raw,p);assert size>=8 and p+size<=len(raw)
        if t==1:
            n,_,flags,st,_=struct.unpack_from('<5I',raw,p+8);assert flags==0
            for i in range(n):
                q=p+st+struct.unpack_from('<I',raw,p+hs+4*i)[0];l=struct.unpack_from('<H',raw,q)[0];strings.append(raw[q+2:q+2+l*2].decode('utf-16le'))
        elif t==0x102:
            _,ni=struct.unpack_from('<II',raw,p+16);ast,asz,ct=struct.unpack_from('<3H',raw,p+24);e=ET.Element(strings[ni])
            for j in range(ct):
                q=p+16+ast+j*asz;ns,name,rv=struct.unpack_from('<3I',raw,q);typ=raw[q+15];v=struct.unpack_from('<I',raw,q+16)[0]
                key=('{'+strings[ns]+'}' if ns!=NONE else '')+strings[name]
                value=strings[v]if typ==3 else str(bool(v)).lower()if typ==0x12 else str(v)
                e.set(key,value)
            if stack:stack[-1].append(e)
            else:root=e
            stack.append(e)
        elif t==0x103:stack.pop()
        p+=size
    assert p==len(raw)and not stack
    return root

def uleb(n):
    assert n>=0;out=bytearray()
    while n>=128:out.append((n&127)|128);n>>=7
    out.append(n);return bytes(out)
def sleb(n):
    out=bytearray()
    while True:
        b=n&127;n>>=7;done=(n==0 and not b&64)or(n==-1 and b&64)
        out.append(b if done else b|128)
        if done:return bytes(out)
def mutf(s):
    out=bytearray();us=s.encode('utf-16le');units=struct.unpack('<'+'H'*(len(us)//2),us)
    for c in units:
        if 1<=c<=127:out.append(c)
        elif c<=2047:out.extend([0xc0|(c>>6),0x80|(c&63)])
        else:out.extend([0xe0|(c>>12),0x80|((c>>6)&63),0x80|(c&63)])
    return uleb(len(units))+out+b'\0'

def M(owner,name,params=(),ret='V'):return(owner,name,tuple(params),ret)
def F(owner,name,typ):return(owner,name,typ)
def shorty(t):return 'L'if t.startswith(('L','['))else t

class Dex:
    def __init__(self):self.classes=[];self.strings=set();self.types=set();self.methods=set();self.fields=set();self.protos=set()
    def add_class(self,name,superclass='Ljava/lang/Object;',interfaces=(),fields=(),methods=()):
        self.classes.append(dict(name=name,super=superclass,interfaces=tuple(interfaces),fields=list(fields),methods=list(methods)))
    def prepare(self):
        for c in self.classes:
            self.types.update([c['name'],c['super'],*c['interfaces']])
            for f,access in c['fields']:self.fields.add(f)
            for m in c['methods']:
                self.methods.add(m['ref'])
                if m.get('js'):self.types.add('Landroid/webkit/JavascriptInterface;')
                if m.get('catch'):self.types.add('Ljava/lang/Exception;')
                for op in m['ops']:
                    kind=op[0]
                    if kind=='s':self.strings.add(op[2])
                    elif kind in['new','array']:self.types.add(op[-1])
                    elif kind in['get','put']:self.fields.add(op[-1])
                    elif kind in['virtual','super','direct','static','interface','vrange']:self.methods.add(op[-1])
        for o,n,p,r in self.methods:self.types.update([o,r,*p]);self.strings.add(n);self.protos.add((r,p))
        for o,n,t in self.fields:self.types.update([o,t]);self.strings.add(n)
        for r,p in self.protos:self.strings.add(shorty(r)+''.join(shorty(x)for x in p))
        self.strings.update(self.types);self.strings.add('EdgeTallLocalBuilder.java')
        self.strings=sorted(self.strings,key=lambda s:s.encode('utf-16be'));self.S={v:i for i,v in enumerate(self.strings)}
        self.types=sorted(self.types,key=self.S.get);self.T={v:i for i,v in enumerate(self.types)}
        self.protos=sorted(self.protos,key=lambda x:(self.T[x[0]],tuple(self.T[t]for t in x[1])));self.P={v:i for i,v in enumerate(self.protos)}
        self.fields=sorted(self.fields,key=lambda f:(self.T[f[0]],self.S[f[1]],self.T[f[2]]));self.F={v:i for i,v in enumerate(self.fields)}
        self.methods=sorted(self.methods,key=lambda m:(self.T[m[0]],self.S[m[1]],self.P[(m[3],m[2])]));self.M={v:i for i,v in enumerate(self.methods)}
        self.classes.sort(key=lambda c:self.T[c['name']])
    def code(self,m):
        words=[];labels={};fix=[];starts=[];maxouts=0
        for op in m['ops']:
            k=op[0]
            if k=='label':labels[op[1]]=len(words);continue
            p=len(words);starts.append(p)
            if k=='s':_,a,s=op;words.extend([0x1a|(a<<8),self.S[s]])
            elif k=='c':
                _,a,v=op
                if a<16 and -8<=v<=7:words.append(0x12|(a<<8)|((v&15)<<12))
                else:words.extend([0x13|(a<<8),v&65535])
            elif k=='new':_,a,t=op;words.extend([0x22|(a<<8),self.T[t]])
            elif k=='array':_,a,b,t=op;words.extend([0x23|(a<<8)|(b<<12),self.T[t]])
            elif k in ['get','put']:
                _,a,b,f=op;words.extend([(0x54 if k=='get'else 0x5b)|(a<<8)|(b<<12),self.F[f]])
            elif k=='movobj':_,a,b=op;words.append(0x07|(a<<8)|(b<<12))
            elif k=='vrange':
                _,start,n,ref=op;maxouts=max(maxouts,n);words.extend([0x74|(n<<8),self.M[ref],start])
            elif k in ['virtual','super','direct','static','interface']:
                _,regs,ref=op;n=len(regs);assert n<=5 and max(regs,default=0)<16;maxouts=max(maxouts,n)
                code={'virtual':0x6e,'super':0x6f,'direct':0x70,'static':0x71,'interface':0x72}[k]
                r=list(regs)+[0]*(5-n);words.extend([code|(r[4]<<8)|(n<<12),self.M[ref],r[0]|r[1]<<4|r[2]<<8|r[3]<<12])
            elif k in ['result','resultobj','exception','return']:
                words.append({'result':0x0a,'resultobj':0x0c,'exception':0x0d,'return':0x0f}[k]|(op[1]<<8))
            elif k=='ret':words.append(0x0e)
            elif k=='aput':_,a,b,c=op;words.extend([0x4d|(a<<8),b|(c<<8)])
            elif k in ['eqz','nez']:_,a,target=op;words.extend([(0x38 if k=='eqz'else 0x39)|(a<<8),0]);fix.append((p+1,p,target))
            elif k in ['eq','ne']:_,a,b,target=op;words.extend([(0x32 if k=='eq'else 0x33)|(a<<8)|(b<<12),0]);fix.append((p+1,p,target))
            elif k=='goto':words.extend([0x29,0]);fix.append((p+1,p,op[1]))
            else:raise ValueError(op)
        for pos,base,t in fix:
            assert t in labels and labels[t]in starts;v=labels[t]-base;assert -32768<=v<=32767;words[pos]=v&65535
        ops=struct.pack('<'+'H'*len(words),*words);tries=1 if m.get('catch')else 0
        data=struct.pack('<HHHHII',m['regs'],m['ins'],maxouts,tries,0,len(words))+ops
        if tries:
            if len(words)%2:data+=b'\0\0'
            start,end,target=m['catch'];data+=struct.pack('<IHH',labels[start],labels[end]-labels[start],1)
            data+=uleb(1)+sleb(1)+uleb(self.T['Ljava/lang/Exception;'])+uleb(labels[target])
        m['audit']={'registers':m['regs'],'inputs':m['ins'],'code_units':len(words),'boundaries':starts,'labels':labels,'try':m.get('catch')}
        return data
    def build(self):
        self.prepare();sections=[];off=112
        for typ,size,count in [(1,4,len(self.strings)),(2,4,len(self.types)),(3,12,len(self.protos)),(4,8,len(self.fields)),(5,8,len(self.methods)),(6,32,len(self.classes))]:
            sections.append((typ,off,count));off+=size*count
        data_off=off;buf=bytearray(off);maps=[(0,1,0)]+[(typ,n,pos)for typ,pos,n in sections if n]
        def align():
            while len(buf)%4:buf.append(0)
        def group(typ,seq,writer,aligned=False):
            offsets=[]
            for v in seq:
                if aligned:align()
                offsets.append(len(buf));buf.extend(writer(v))
            if seq:maps.append((typ,len(seq),offsets[0]))
            return offsets
        typesets=sorted(set([p for r,p in self.protos if p]+[c['interfaces']for c in self.classes if c['interfaces']]),key=lambda p:tuple(self.T[t]for t in p))
        tl_off=group(0x1001,typesets,lambda p:P32(len(p))+b''.join(P16(self.T[t])for t in p),True);tl=dict(zip(typesets,tl_off))
        so=group(0x2002,self.strings,mutf)
        all_methods=[m for c in self.classes for m in c['methods']]
        js=[m for m in all_methods if m.get('js')]
        anno=group(0x2004,js,lambda m:b'\1'+uleb(self.T['Landroid/webkit/JavascriptInterface;'])+uleb(0))
        aset=group(0x1003,anno,lambda o:P32(1)+P32(o),True)
        dirs=[]
        for c in self.classes:
            ls=[(self.M[m['ref']],aset[js.index(m)])for m in c['methods']if m in js]
            if ls:dirs.append((c,ls))
        adir=group(0x2006,dirs,lambda x:P32(0)+P32(0)+P32(len(x[1]))+P32(0)+b''.join(P32(m)+P32(o)for m,o in sorted(x[1])),True)
        dir_map={c['name']:o for (c,ls),o in zip(dirs,adir)}
        codes=group(0x2001,all_methods,self.code,True);code_off={m['ref']:o for m,o in zip(all_methods,codes)}
        def cdata(c):
            direct=sorted([m for m in c['methods']if m['access']&(0x10000|0x2|0x8)],key=lambda m:self.M[m['ref']]);virtual=sorted([m for m in c['methods']if m not in direct],key=lambda m:self.M[m['ref']]);fs=sorted(c['fields'],key=lambda x:self.F[x[0]])
            out=uleb(0)+uleb(len(fs))+uleb(len(direct))+uleb(len(virtual));prev=0
            for f,access in fs:idx=self.F[f];out+=uleb(idx-prev)+uleb(access);prev=idx
            for ml in [direct,virtual]:
                prev=0
                for m in ml:idx=self.M[m['ref']];out+=uleb(idx-prev)+uleb(m['access'])+uleb(code_off[m['ref']]);prev=idx
            return out
        cdo=group(0x2000,self.classes,cdata)
        align();map_off=len(buf);maps.append((0x1000,1,map_off));maps.sort(key=lambda x:x[2]);buf+=P32(len(maps))+b''.join(struct.pack('<HHII',t,0,n,p)for t,n,p in maps)
        for (typ,pos,n)in sections:
            if typ==1:raw=b''.join(P32(o)for o in so)
            elif typ==2:raw=b''.join(P32(self.S[t])for t in self.types)
            elif typ==3:raw=b''.join(P32(self.S[shorty(r)+''.join(shorty(t)for t in p)])+P32(self.T[r])+P32(tl.get(p,0))for r,p in self.protos)
            elif typ==4:raw=b''.join(P16(self.T[o])+P16(self.T[t])+P32(self.S[name])for o,name,t in self.fields)
            elif typ==5:raw=b''.join(P16(self.T[o])+P16(self.P[(r,p)])+P32(self.S[name])for o,name,p,r in self.methods)
            elif typ==6:raw=b''.join(struct.pack('<8I',self.T[c['name']],1,self.T[c['super']],tl.get(c['interfaces'],0),self.S['EdgeTallLocalBuilder.java'],dir_map.get(c['name'],0),cdo[i],0)for i,c in enumerate(self.classes))
            buf[pos:pos+len(raw)]=raw
        hdr=bytearray(b'dex\n035\0'+b'\0'*24)
        hdr+=struct.pack('<6I',len(buf),112,0x12345678,0,0,map_off)
        for typ,pos,n in sections:hdr+=P32(n)+P32(pos if n else 0)
        hdr+=P32(len(buf)-data_off)+P32(data_off);assert len(hdr)==112;buf[:112]=hdr
        buf[12:32]=hashlib.sha1(buf[32:]).digest();buf[8:12]=P32(zlib.adler32(buf[12:])&0xffffffff)
        return bytes(buf),{'types':self.types,'strings':self.strings,'classes':[{k:v for k,v in c.items()if k!='methods'}for c in self.classes],'methods':[{'ref':m['ref'],'offset':code_off[m['ref']],**m['audit']}for m in all_methods]}
