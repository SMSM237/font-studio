from pathlib import Path
import zipfile,struct,hashlib,datetime,secrets,subprocess,sys,json,io
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import rsa,padding
from cryptography.hazmat.primitives.serialization import pkcs12
ROOT=Path(__file__).resolve().parents[1]
def lp(a):return struct.pack('<I',len(a))+a

def sign_v2(raw,key,cert):
 e=raw.rfind(b'PK\x05\x06');assert e>=0
 cd=struct.unpack_from('<I',raw,e+16)[0];parts=[raw[:cd],raw[cd:e],raw[e:]];chunks=[]
 for p in parts:
  for j in range(0,len(p),1048576):
   c=p[j:j+1048576];chunks.append(hashlib.sha256(b'\xa5'+struct.pack('<I',len(c))+c).digest())
 digest=hashlib.sha256(b'\x5a'+struct.pack('<I',len(chunks))+b''.join(chunks)).digest()
 alg=struct.pack('<I',0x103);certb=cert.public_bytes(serialization.Encoding.DER)
 signed=lp(lp(alg+lp(digest)))+lp(lp(certb))+lp(b'')
 sig=key.sign(signed,padding.PKCS1v15(),hashes.SHA256())
 pub=key.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
 signer=lp(signed)+lp(lp(alg+lp(sig)))+lp(pub)
 value=lp(lp(signer));pair=struct.pack('<Q',4+len(value))+struct.pack('<I',0x7109871a)+value
 size=len(pair)+24;block=struct.pack('<Q',size)+pair+struct.pack('<Q',size)+b'APK Sig Block 42'
 end=bytearray(parts[2]);struct.pack_into('<I',end,16,cd+len(block))
 return parts[0]+block+parts[1]+end

def align_zip(raw):
 # jarsigner adds ZIP entries ahead of the payload; align AFTER JAR signing.
 # Rebuilding ZIP metadata does not change any JAR-signed entry content.
 output=io.BytesIO()
 with zipfile.ZipFile(io.BytesIO(raw)) as source,zipfile.ZipFile(output,'w') as dest:
  for old in source.infolist():
   name=old.filename;info=zipfile.ZipInfo(name,date_time=old.date_time)
   info.compress_type=zipfile.ZIP_STORED if name in ('classes.dex','resources.arsc') else zipfile.ZIP_DEFLATED
   if info.compress_type==zipfile.ZIP_STORED:
    padding_len=(-(dest.fp.tell()+30+len(name.encode('utf-8'))+4))%4
    info.extra=struct.pack('<HH',0xd935,padding_len)+b'\0'*padding_len
   dest.writestr(info,source.read(name))
 return output.getvalue()

def main():
 priv=ROOT/'build/private';priv.mkdir(exist_ok=True)
 keypath=priv/'signing-key.pem';certpath=priv/'signing-cert.pem'
 if keypath.exists():
  key=serialization.load_pem_private_key(keypath.read_bytes(),None);cert=x509.load_pem_x509_certificate(certpath.read_bytes())
 else:
  key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
  name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'FONT Studio - Personal Build')])
  now=datetime.datetime.now(datetime.timezone.utc)
  cert=x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(days=2)).not_valid_after(now+datetime.timedelta(days=3650)).sign(key,hashes.SHA256())
  keypath.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()));certpath.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
 pwd=secrets.token_urlsafe(24);p12=priv/'signer.p12'
 p12.write_bytes(pkcs12.serialize_key_and_certificates(b'edgebuilder',key,cert,None,serialization.BestAvailableEncryption(pwd.encode())))
 unsigned=ROOT/'build/helper-v1.apk'
 with zipfile.ZipFile(unsigned,'w')as z:
  for name,path in [('AndroidManifest.xml',ROOT/'build/AndroidManifest.xml'),('resources.arsc',ROOT/'build/resources.arsc'),('classes.dex',ROOT/'build/classes.dex'),('assets/index.html',ROOT/'assets/index.html'),('res/drawable-nodpi/font_logo.png',ROOT/'res/drawable-nodpi/font_logo.png')]:
   info=zipfile.ZipInfo(name,date_time=(2026,9,13,0,0,0));info.compress_type=zipfile.ZIP_STORED if name in ('classes.dex','resources.arsc') else zipfile.ZIP_DEFLATED
   if name in ('classes.dex','resources.arsc'):
    n=(-(z.fp.tell()+30+len(name.encode())+4))%4;info.extra=struct.pack('<HH',0xd935,n)+b'\0'*n
   z.writestr(info,path.read_bytes())
 r=subprocess.run(['jarsigner','-keystore',str(p12),'-storetype','PKCS12','-storepass',pwd,'-sigalg','SHA256withRSA','-digestalg','SHA-256',str(unsigned),'edgebuilder'],capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stdout+r.stderr)
 output=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'dist/FONT_Studio_v4.apk';output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(sign_v2(align_zip(unsigned.read_bytes()),key,cert))
 r=subprocess.run(['jarsigner','-verify','-verbose','-certs',str(output)],capture_output=True,text=True)
 (ROOT/'build/jarsigner-verification.txt').write_text(r.stdout+r.stderr)
 assert r.returncode==0 and 'jar verified.' in r.stdout
 sys.path.insert(0,str(ROOT/'tests'));from test_apk_signature import verify_v2
 v=verify_v2(output);v.update(size_bytes=output.stat().st_size,v1_jar_verified=True,physical_device_tested=False)
 (ROOT/'build/helper_signature_validation.json').write_text(json.dumps(v,indent=2));print(json.dumps(v,indent=2))
if __name__=='__main__':main()
