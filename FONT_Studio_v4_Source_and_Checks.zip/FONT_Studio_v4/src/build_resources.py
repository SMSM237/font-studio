"""Create a small app-icon resource table; no Android SDK or font assets needed."""
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
(ROOT/'build').mkdir(exist_ok=True)
subprocess.run(['node','-e',"const fs=require('fs'),S=require('./assets/font-studio.js');fs.writeFileSync('build/resources.arsc',S.resourcesArsc('app.fontstudio.editor4'));"],cwd=ROOT,check=True)
