// Small deterministic CommonJS bundler for the already installed audited packages.
// No runtime downloads, eval, or font data.
const fs=require('fs'),path=require('path'),{createRequire}=require('module');
const root=path.resolve(__dirname,'..'),entry='/usr/local/slides_js/node_modules/fontkit/dist/browser.cjs';
const ids=new Map(),sources=[],meta=[];
function add(file){if(ids.has(file))return ids.get(file);const id=ids.size;ids.set(file,id);sources[id]='';
 let code=fs.readFileSync(file,'utf8');if(file.endsWith('.json'))code='module.exports='+code+';';
 const deps={};const req=createRequire(file);
 for(const m of code.matchAll(/\brequire\(\s*['"]([^'"]+)['"]\s*\)/g)){
  const key=m[1];if(deps[key]!==undefined)continue;
  let res;try{res=req.resolve(key)}catch(e){throw Error(file+' '+key+' '+e.message)}
  if(!path.isAbsolute(res))throw Error('Unexpected native module: '+res);
  deps[key]=add(res);
 }
 code=code.replace(/\/\/# sourceMappingURL=.*$/mg,'');
 sources[id]=JSON.stringify(id)+':[function(module,exports,require){\n'+code+'\n},'+JSON.stringify(deps)+']';
 meta[id]={id,file:file.replace('/usr/local/slides_js/node_modules/',''),bytes:Buffer.byteLength(code)};return id;
}
const id=add(entry);
let text=`/* fontkit 2.0.4 and dependencies; see THIRD_PARTY_LICENSES.txt. */\nconst FontkitLocal=(()=>{const mods={${sources.join(',\n')}};const cache={};function load(id){if(cache[id])return cache[id].exports;const m={exports:{}};cache[id]=m;const [f,d]=mods[id];f(m,m.exports,k=>{if(!(k in d))throw Error('Unbundled dependency '+k);return load(d[k]);});return m.exports;}return load(${id});})();\nif(typeof module!=='undefined')module.exports=FontkitLocal;\n`;
fs.writeFileSync(path.join(root,'vendor/fontkit-local.js'),text);
fs.writeFileSync(path.join(root,'vendor/bundle-manifest.json'),JSON.stringify(meta,null,2));
const packages=new Set();for(const file of ids.keys()){let p=path.dirname(file);while(p!=='/'&&!fs.existsSync(path.join(p,'package.json')))p=path.dirname(p);packages.add(p);}
let licenses='Runtime font parser: fontkit 2.0.4. All dependencies bundled offline.\nNo font assets are bundled.\n';
for(const p of packages){const j=JSON.parse(fs.readFileSync(path.join(p,'package.json')));licenses+='\n\n===== '+j.name+' '+j.version+' ('+j.license+') =====\n';const lf=fs.readdirSync(p).find(n=>/^licen[cs]e/i.test(n));if(lf)licenses+=fs.readFileSync(path.join(p,lf),'utf8');else licenses+='License: '+j.license+'\n';}
fs.writeFileSync(path.join(root,'THIRD_PARTY_LICENSES.txt'),licenses);
console.log('Bundled',sources.length,'modules;',text.length,'chars');
