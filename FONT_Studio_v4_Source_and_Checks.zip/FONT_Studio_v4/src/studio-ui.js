'use strict';
const $=id=>document.getElementById(id),keys=['width','height','weight','spacing'];
const LOGO=EdgeB.unb64('/*ICON*/');
let candidates=[],selected=null,source=null,finalFont=null,finalIdentity=null,finalApk=null,lastBuiltIdentity=null;
let currentFace=null,normalFace=null,revision=0,committed=-1,pendingTimer=null,busy=false,zeroOK=false,nameDirty=false;
let latestMetrics={width:0,height:0},displayOptions={...EdgeB.DEFAULTS};
function setStatus(text,kind=''){$('status').textContent=text;$('status').className=kind}
function readOptions(){const values=Object.fromEntries([...keys.map(k=>[k,Number($(k).value)]),['leadingZero',$('zero').checked]]);if(!selected)return {...EdgeB.DEFAULTS};return selected.mode==='oppo'?EdgeB.optionsFor(values):FontStudio.editOptions(selected.bytes,values)}
function applyOptions(o){for(const k of keys){$(k).value=o[k];$(k+'Range').value=o[k]}$('zero').checked=o.leadingZero;updateSummary()}
function updateSummary(){
 try{const name=FontStudio.validateName($('fontName').value),o=readOptions();displayOptions=o;
  $('nameError').textContent='';$('outputNames').textContent=`파일명  ${name}.apk\n설치 앱명  ${name}\n글꼴 목록·내부 이름  ${name}`;
  $('summary').textContent=`가로 ${o.width}% · 세로 ${o.height}% · 두께 ${o.weight}\n간격 ${o.spacing}% em · 앞자리 0 ${o.leadingZero?'켬 (실험적)':'끔'}`;
 }catch(e){$('nameError').textContent=e.message;$('summary').textContent='이름과 조절값을 확인하세요.'}
}
function isReady(){return !!finalFont&&!!finalIdentity&&committed===revision&&!pendingTimer}
function busyControls(on){busy=on;const disabled=on||!selected||(selected.mode!=='oppo'&&!selected.capabilities.supported);for(const el of document.querySelectorAll('.control input,#zero,#reset'))el.disabled=disabled;$('zero').disabled=disabled||!selected||selected.mode!=='oppo';for(const id of ['input','faceSelect','fontName'])$(id).disabled=on;$('build').disabled=on||!isReady()}
function updateMode(){
 const oppo=selected&&selected.mode==='oppo',cap=selected&&!oppo?selected.capabilities:null;
 $('modeName').textContent=!selected?'폰트 선택 대기':oppo?'OPPO B안 · 편집 모드':cap.supported?'일반 폰트 · 실제 윤곽선 편집':'이 형식은 편집할 수 없습니다';
 $('modeHint').textContent=oppo?'기존 B안을 그대로 유지합니다. 가로·세로·두께·간격을 최종 폰트에 반영합니다.':cap?(cap.supported?'선택한 글꼴의 모든 글자를 실제로 변형한 뒤 정적 TTF로 저장합니다. OTF도 편집할 수 있습니다.':cap.reason):'TTF/OTF 또는 폰트가 들어 있는 APK를 선택하세요.';
 $('reset').textContent=oppo?'B안 초기화':'원본 크기·두께';$('genericNotice').hidden=!selected||oppo;
 $('genericNotice').textContent=cap?cap.notice+' 고급 수식·세로쓰기와 비트맵 힌팅은 편집 대상이 아닙니다.':'';
 const w=oppo?{min:0,max:1000,default:500}:cap?{min:cap.weightMin,max:cap.weightMax,default:cap.weightDefault}:{min:-15,max:30,default:0};
 for(const id of ['weight','weightRange']){const el=$(id);el.min=w.min;el.max=w.max;el.step=1;}
 $('weightHint').textContent=oppo||cap&&cap.weightMode==='axis'?'원본 가변축 wght · 실제 굵기를 확정합니다.':'정적 폰트 윤곽선 보정 · 0=원본, 음수=얇게, 양수=두껍게';
 $('weightUnit').textContent=oppo||cap&&cap.weightMode==='axis'?'축 값':'‰ em';
 $('weightMinLabel').textContent=w.min+' · 얇게';$('weightMaxLabel').textContent=w.max+' · 두껍게';
 $('heightHint').textContent=oppo?'B안 높이의 배율 · 가로와 독립':'선택한 원본 높이의 배율 · 가로와 독립';
 $('zeroHelp').textContent=oppo?'폰트 치환 규칙으로 8:45 → 08:45를 시도합니다. 삼성 잠금화면 적용은 별도 확인이 필요합니다.':'일반 폰트는 기존 문자 치환을 보존합니다. 앞자리 0 실험은 OPPO 시계 폰트에서만 지원합니다.';
 $('sourceInfo').textContent=selected?`${selected.extension.toUpperCase()} · ${selected.glyphs.toLocaleString()} 글리프${selected.variable?' · 가변 폰트':''}\n${selected.name}`:'';
 $('copyright').textContent=selected?[selected.copyright,selected.license].filter(Boolean).join('\n'):'원본 파일 선택 후 확인할 수 있습니다.';
 busyControls(busy);
}
function validSample(){const text=$('sampleText').value;if(!text.length){$('sampleError').textContent='미리보기 글자를 입력하세요.';return null}
 if(selected&&selected.mode==='oppo'&&(!/^\d{1,2}:[0-5]\d(?::[0-5]\d)?$/.test(text)||Number(text.split(':')[0])>23)){$('sampleError').textContent='0:00~23:59 형식의 시간을 입력하세요.';return null}
 const missing=finalFont?FontStudio.missingCharacters(finalFont,text):[];$('sampleError').textContent=missing.length?'원본에 없는 글자: '+missing.join(' ')+' — 대체 글꼴로 보일 수 있습니다.':'';return text;
}
function paint(){
 const cv=$('canvas'),cx=cv.getContext('2d');cx.clearRect(0,0,cv.width,cv.height);cx.strokeStyle='#33465f';cx.lineWidth=1;cx.setLineDash([8,8]);cx.strokeRect(42,42,636,746);cx.setLineDash([]);cx.strokeStyle='#213147';cx.beginPath();cx.moveTo(360,20);cx.lineTo(360,824);cx.stroke();
 if(!currentFace)return;const text=validSample();if(!text)return;let px=220;cx.font=`${px}px "${currentFace.family}"`;let m=cx.measureText(text),width=m.actualBoundingBoxLeft+m.actualBoundingBoxRight,height=m.actualBoundingBoxAscent+m.actualBoundingBoxDescent;
 if($('fit').checked&&width&&height){px*=Math.min(620/width,730/height);cx.font=`${px}px "${currentFace.family}"`;m=cx.measureText(text);width=m.actualBoundingBoxLeft+m.actualBoundingBoxRight;height=m.actualBoundingBoxAscent+m.actualBoundingBoxDescent}
 const x=360-width/2+m.actualBoundingBoxLeft,baseline=$('fit').checked?42+(746-height)/2+m.actualBoundingBoxAscent:760;cx.fillStyle='#f5f7fc';cx.fillText(text,x,baseline);
 latestMetrics={width:+width.toFixed(2),height:+height.toFixed(2),fontSize:+px.toFixed(2),input:text,fit:$('fit').checked};$('measure').textContent=`가로 ${Math.round(width)} · 세로 ${Math.round(height)} px`;
 $('sizeWarning').textContent=(width>636||baseline-m.actualBoundingBoxAscent<42||baseline+m.actualBoundingBoxDescent>788)?'가이드를 넘습니다. 배율을 줄이거나 영역 맞춤으로 전체를 확인하세요.':'';
 $('shapeStatus').textContent=($('fit').checked?'영역 맞춤 · 절대 크기 비교에는 고정 배율을 사용하세요.':'고정 배율 · 720 px 기준 / 기기 픽셀과 다릅니다.')+(displayOptions.leadingZero?'\n'+(zeroOK?'이 WebView에서 앞자리 0 치환 확인':'이 WebView에서는 0 치환을 확인하지 못했습니다.'):'');
}
function raster(face,text){const c=document.createElement('canvas');c.width=1500;c.height=900;const x=c.getContext('2d');x.font=`180px "${face.family}"`;x.fillText(text,30,800);return x.getImageData(0,0,c.width,c.height).data}
function samePixels(a,b){if(a.length!==b.length)return false;for(let i=0;i<a.length;i++)if(a[i]!==b[i])return false;return true}
function checkZero(face,off){return samePixels(raster(face,'8:45'),raster(off,'08:45'))&&samePixels(raster(face,'10:45'),raster(off,'10:45'))&&samePixels(raster(face,'1:08'),raster(off,'01:08'))}
async function regenerate(id){
 if(!selected)return;let face=null,off=null;
 try{
  const item=selected,name=FontStudio.validateName($('fontName').value),o=readOptions(),identity=await FontStudio.identityForName(name);if(id!==revision)return;
  setStatus('실제 글리프를 변환하고 있습니다.');
  const raw=item.mode==='oppo'?EdgeB.instantiate(item.bytes,o):await FontStudio.editFont(item.bytes,o,{cancelled:()=>id!==revision,progress:(n,total)=>{if(id===revision)setStatus(`글리프 변환 ${n.toLocaleString()} / ${total.toLocaleString()}`)}});
  if(id!==revision)return;
  const out=FontStudio.fontNamed(raw,name,identity.postScriptName);
  if(EdgeB.checksum(out)!==0xb1b0afba)throw Error('폰트 체크섬 검증에 실패했습니다.');
  face=new FontFace('FontStudioLive'+id,out.buffer);await face.load();if(id!==revision)return;document.fonts.add(face);let checked=false;
  if(o.leadingZero&&item.mode==='oppo'){const no=FontStudio.fontNamed(EdgeB.instantiate(item.bytes,{...o,leadingZero:false}),name,identity.postScriptName);off=new FontFace('FontStudioPlain'+id,no.buffer);await off.load();document.fonts.add(off);checked=checkZero(face,off)}
  if(id!==revision){document.fonts.delete(face);if(off)document.fonts.delete(off);return}
  if(currentFace)document.fonts.delete(currentFace);if(normalFace)document.fonts.delete(normalFace);
  currentFace=face;normalFace=off;finalFont=out;finalIdentity=identity;finalApk=null;zeroOK=checked;displayOptions=o;committed=id;$('empty').hidden=true;
  paint();updateSummary();busyControls(busy);if(item.mode==='oppo')try{localStorage.setItem('fontstudio-v3-oppo-settings',JSON.stringify(o))}catch(_){}
  setStatus(item.mode==='oppo'?'B안 편집 완료. 현재 미리보기와 같은 폰트로 APK를 만듭니다.':'일반 폰트 편집 완료. 가로·세로·두께·간격을 반영한 동일한 글리프로 APK를 만듭니다.','ok');
 }catch(e){if(face)document.fonts.delete(face);if(off)document.fonts.delete(off);if(id!==revision)return;finalFont=null;finalIdentity=null;committed=-1;$('build').disabled=true;setStatus(e.message||String(e),'error')}
}
function queueChange(){revision++;committed=-1;finalApk=null;$('build').disabled=true;$('build').textContent='이 이름으로 APK 생성';$('saved').hidden=true;updateSummary();if(pendingTimer)clearTimeout(pendingTimer);pendingTimer=setTimeout(()=>{pendingTimer=null;regenerate(revision)},140)}
function clearSource(){revision++;committed=-1;finalFont=null;finalIdentity=null;finalApk=null;selected=null;source=null;if(pendingTimer){clearTimeout(pendingTimer);pendingTimer=null}if(currentFace)document.fonts.delete(currentFace);if(normalFace)document.fonts.delete(normalFace);currentFace=normalFace=null;$('empty').hidden=false;$('measure').textContent='가로 — · 세로 —';$('saved').hidden=true;paint()}
async function chooseFace(index){selected=candidates[index];if(!selected)throw Error('선택한 글꼴이 없습니다.');source=selected.bytes;
 if(!nameDirty)$('fontName').value=selected.mode==='oppo'?'나의 시계':FontStudio.suggestedName(selected.name);
 if(selected.mode==='oppo'){$('sampleText').value='8:45';updateMode();applyOptions({...EdgeB.DEFAULTS})}else{updateMode();applyOptions({...selected.capabilities.defaults});$('sampleText').value='8:45'}$('fit').checked=false;
 revision++;committed=-1;if(pendingTimer){clearTimeout(pendingTimer);pendingTimer=null}updateMode();await regenerate(revision);
}
async function loadInput(bytes,fileName){
 candidates=await FontStudio.importFiles(bytes,fileName);$('fileName').textContent=fileName;$('faceSelect').replaceChildren();
 for(let i=0;i<candidates.length;i++){const op=document.createElement('option');op.value=String(i);op.textContent=`${i+1}. ${candidates[i].name} (${candidates[i].extension})`;$('faceSelect').append(op)}
 $('faceRow').hidden=candidates.length<=1;await chooseFace(0);
}
for(const key of keys){$(key).addEventListener('input',()=>{$(key+'Range').value=$(key).value;queueChange()});$(key+'Range').addEventListener('input',()=>{$(key).value=$(key+'Range').value;queueChange()})}
$('fontName').addEventListener('input',()=>{nameDirty=true;queueChange()});$('fontName').addEventListener('blur',()=>{try{const n=FontStudio.validateName($('fontName').value);if(n!==$('fontName').value){$('fontName').value=n;queueChange()}}catch(_){}});
$('zero').addEventListener('change',queueChange);$('fit').addEventListener('change',paint);$('sampleText').addEventListener('input',paint);
for(const b of document.querySelectorAll('[data-time]'))b.addEventListener('click',()=>{$('sampleText').value=b.dataset.time;paint()});
$('reset').addEventListener('click',()=>{applyOptions(selected&&selected.mode!=='oppo'?{...selected.capabilities.defaults}:{...EdgeB.DEFAULTS});$('fit').checked=false;queueChange()});
$('faceSelect').addEventListener('change',async()=>{busyControls(true);try{await chooseFace(Number($('faceSelect').value))}catch(e){setStatus(e.message,'error')}finally{busyControls(false)}});
$('input').addEventListener('change',async()=>{
 if(busy)return;const f=$('input').files&&$('input').files[0];if(!f)return;clearSource();candidates=[];$('faceRow').hidden=true;busyControls(true);setStatus('폰트 형식과 포함 글꼴을 확인하고 있습니다.');
 try{if(f.size>FontStudio.MAX_INPUT)throw Error('입력 파일은 64 MB 이하여야 합니다.');if(!crypto.subtle)throw Error('보안 암호화 API가 없습니다. 시스템 WebView를 확인하세요.');await loadInput(new Uint8Array(await f.arrayBuffer()),f.name)}catch(e){clearSource();updateMode();setStatus(e.message||String(e),'error')}finally{busyControls(false)}
});
function entriesForCurrent(version){if(!isReady())throw Error('이름 또는 폰트 갱신이 끝나지 않았습니다.');return FontStudio.packageEntries(finalFont,{name:finalIdentity.name,identity:finalIdentity,version,logo:LOGO,settings:displayOptions,mode:selected.mode,source:{name:selected.name,sha256:selected.sha256}})}
async function save(){
 if(window.Native&&typeof Native.saveApk==='function'){Native.saveApk(EdgeB.b64(finalApk),lastBuiltIdentity.fileName);setStatus('저장창에서 위치를 지정하세요. 설치 이름은 앱에서 입력한 이름으로 이미 반영되어 있습니다.');}
 else{const url=URL.createObjectURL(new Blob([finalApk],{type:'application/vnd.android.package-archive'})),a=document.createElement('a');a.href=url;a.download=lastBuiltIdentity.fileName;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);setStatus('다운로드를 요청했습니다. 다운로드 완료 여부를 확인하세요.','ok');busyControls(false)}
}
$('build').addEventListener('click',async()=>{
 if(!isReady()||busy)return;busyControls(true);$('saved').hidden=true;
 try{if(!finalApk){setStatus('입력한 이름과 로고를 반영하고 APK에 서명하는 중입니다.');const version=FontStudio.nextVersion(finalIdentity.packageName),entries=entriesForCurrent(version);finalApk=await EdgeB.signApk(entries);lastBuiltIdentity={...finalIdentity}}await save()}
 catch(e){setStatus('저장하지 않았습니다. '+(e.message||e),'error');busyControls(false)}
});
window.nativeSaved=()=>{setStatus('APK를 저장했습니다. 내 파일에서 저장한 파일을 설치하세요.','ok');$('saved').textContent=`저장한 파일: ${lastBuiltIdentity?lastBuiltIdentity.fileName:'APK'}\n설치 앱명·글꼴명: ${lastBuiltIdentity?lastBuiltIdentity.name:''}\n폰트 패키지는 실행 화면이 없는 데이터 앱입니다.`;$('saved').hidden=false;$('build').textContent='같은 APK 다시 저장';busyControls(false)};
window.nativeSaveCancelled=()=>{setStatus('저장을 취소했습니다. 설정과 이름을 유지합니다.');busyControls(false)};
window.nativeError=()=>{setStatus('APK 저장에 실패했습니다. 저장 위치를 확인하고 다시 시도하세요.','error');busyControls(false)};
const Studio={capabilities:()=>selected&&selected.capabilities,loadInput,options:()=>({...displayOptions}),ready:isReady,metrics:()=>({...latestMetrics}),fontBytes:()=>finalFont,identity:()=>finalIdentity,mode:()=>selected&&selected.mode,zeroVerified:()=>zeroOK,packageEntries:entriesForCurrent};
try{const o=localStorage.getItem('fontstudio-v3-oppo-settings');if(o)applyOptions(EdgeB.optionsFor(JSON.parse(o)))}catch(_){}
updateMode();updateSummary();busyControls(false);paint();
