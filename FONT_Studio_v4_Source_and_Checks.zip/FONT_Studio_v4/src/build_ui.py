from pathlib import Path
import base64, html
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'src/ui.html').read_text()
s=s.replace('/*LICENSES*/',html.escape((ROOT/'THIRD_PARTY_LICENSES.txt').read_text()))
s=s.replace('/*FONTKIT*/',(ROOT/'vendor/fontkit-local.js').read_text()).replace('/*GENERIC*/',(ROOT/'assets/generic-editor.js').read_text())
s=s.replace('/*ENGINE*/',(ROOT/'assets/engine.js').read_text()).replace('/*FONTSTUDIO*/',(ROOT/'assets/font-studio.js').read_text()).replace('/*UIJS*/',(ROOT/'src/studio-ui.js').read_text()).replace('/*ICON*/',base64.b64encode((ROOT/'res/drawable-nodpi/font_logo.png').read_bytes()).decode()).replace('/*LOGO*/',base64.b64encode((ROOT/'assets/logo.png').read_bytes()).decode())
assert all(t not in s for t in ['/*ENGINE*/','/*UIJS*/','/*ICON*/','/*LOGO*/','/*FONTSTUDIO*/','/*FONTKIT*/','/*GENERIC*/'])
(ROOT/'assets/index.html').write_text(s)
print('FONT Studio 4 UI:',len(s.encode()),'bytes; no font binaries included')
