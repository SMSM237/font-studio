"""Build FONT Studio 4.0, without bundling any font or signing private key.
Prerequisites: Python 3 + cryptography, Node 20+, JDK 17+ with jarsigner.
No Android SDK is needed by this handcrafted framework-only bridge.
"""
from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
(ROOT/'build').mkdir(exist_ok=True)
output=Path(sys.argv[1]).resolve()if len(sys.argv)>1 else ROOT/'dist/FONT_Studio_v4.apk'
for script,args in [
 ('src/build_ui.py',[]),('src/build_resources.py',[]),('src/build_bridge.py',[]),
 ('tests/verify_dex.py',[]),('tests/test_v4_native.py',[]),
 ('src/sign_helper.py',[str(output)]),('tests/final_package_check.py',[str(output)])
]:
 subprocess.run([sys.executable,str(ROOT/script),*args],check=True,cwd=ROOT)
print('Verified build:',output)
