"""Raster proof from actual edited font bytes; does not distribute font files."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import subprocess,json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'build/tests'
# A standard static TrueType, not the OPPO font.
source=OUT/'latin.ttf'
configs=[('Original',{},'원본'),('Width 80% / Height 140%',{'width':80,'height':140},'가로·세로 실제 변환'),('Weight -5',{'weight':-5},'일반 폰트 · 더 얇게'),('Weight +8',{'weight':8},'일반 폰트 · 더 두껍게')]
paths=[]
for label,cfg,k in configs:
 target=OUT/('proof-'+str(len(paths))+'.ttf');subprocess.run(['node',str(ROOT/'tests/export_v4.cjs'),str(source),json.dumps(cfg),str(target)],check=True,capture_output=True,text=True);paths.append((label,target,k))
W,H=1280,1400;im=Image.new('RGB',(W,H),(16,21,31));d=ImageDraw.Draw(im)
labelpath='/usr/share/fonts/truetype/nanum/NanumGothic.ttf';title=ImageFont.truetype(labelpath,31);small=ImageFont.truetype(labelpath,22)
d.text((48,32),'FONT Studio 4 · 일반 TTF 실제 편집 결과',font=title,fill=(238,241,248));d.text((48,82),'같은 글자 크기 170 px · 가상 굵기나 이미지 늘이기가 아닌 결과 폰트 렌더링',font=small,fill=(162,178,205))
for i,(label,path,k)in enumerate(paths):
 y=145+i*290;d.rounded_rectangle((35,y,W-35,y+269),radius=17,fill=(25,34,49));d.text((59,y+17),label+'  |  '+k,font=small,fill=(179,199,233));f=ImageFont.truetype(str(path),170);d.text((60,y+248),'FONT 08:45',font=f,fill=(245,247,252),anchor='ls')
d.text((48,H-45),'테스트 글꼴: DejaVu Sans · 결과 PNG만 제공 · 기기 잠금화면 캡처는 아님',font=small,fill=(148,165,190));im.save(ROOT/'build/FONT_Studio_v4_edit_proof.png')
