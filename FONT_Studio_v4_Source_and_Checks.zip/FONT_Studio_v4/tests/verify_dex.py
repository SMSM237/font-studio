"""Independent structural/register-reference validation of the emitted DEX.
This is not an ART emulator or an Android installation test.
"""
import struct,hashlib,zlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def uleb(b,p):
 n=s=0
 while True:
  x=b[p];p+=1;n|=(x&127)<<s
  if x<128:return n,p
  s+=7;assert s<35

def main():
 b=(ROOT/'build/classes.dex').read_bytes();assert b[:8]==b'dex\n035\0';assert struct.unpack_from('<I',b,8)[0]==zlib.adler32(b[12:])&0xffffffff;assert b[12:32]==hashlib.sha1(b[32:]).digest()
 h=struct.unpack_from('<20I',b,32);assert h[0]==len(b)and h[1]==112 and h[2]==0x12345678
 nstr,ostr,nt,ot,np,op,nf,of,nm,om,nc,oc,ds,do=h[6:];assert do+ds==len(b)
 strings=[]
 for i in range(nstr):
  p=struct.unpack_from('<I',b,ostr+i*4)[0];n,p=uleb(b,p);end=b.index(0,p);s=b[p:end].decode('utf-8');strings.append(s)
 assert strings==sorted(set(strings),key=lambda s:s.encode('utf-16be'))
 types=[strings[struct.unpack_from('<I',b,ot+4*i)[0]]for i in range(nt)]
 def typelist(p):
  if not p:return[]
  n=struct.unpack_from('<I',b,p)[0];return[types[struct.unpack_from('<H',b,p+4+2*i)[0]]for i in range(n)]
 protos=[]
 for i in range(np):
  si,ri,po=struct.unpack_from('<III',b,op+12*i);protos.append((types[ri],typelist(po)))
 methods=[]
 for i in range(nm):
  ti,pi,si=struct.unpack_from('<HHI',b,om+8*i);assert ti<nt and pi<np and si<nstr;methods.append((types[ti],strings[si],*protos[pi]))
 fields=[]
 for i in range(nf):
  ti,fi,si=struct.unpack_from('<HHI',b,of+8*i);assert ti<nt and fi<nt and si<nstr;fields.append((types[ti],strings[si],types[fi]))
 defined=[];js_annotations=0
 for ci in range(nc):
  cidx,flags,sidx,ifoff,src,anno,cdata,stat=struct.unpack_from('<8I',b,oc+ci*32);assert flags&1;assert sidx<nt
  if anno:
   ca,fs,ms,ps=struct.unpack_from('<4I',b,anno);assert(fs,ms,ps)==(0,1,0)
   mid,aset=struct.unpack_from('<II',b,anno+16);assert methods[mid][1]=='saveApk'
   n,ai=struct.unpack_from('<II',b,aset);assert n==1 and b[ai]==1
   tid,p=uleb(b,ai+1);count,p=uleb(b,p);assert types[tid]=='Landroid/webkit/JavascriptInterface;'and count==0;js_annotations+=1
  sizes=[];p=cdata
  for _ in range(4):n,p=uleb(b,p);sizes.append(n)
  for count in sizes[:2]:
   idx=0
   for _ in range(count):d,p=uleb(b,p);idx+=d;af,p=uleb(b,p);assert idx<nf and fields[idx][0]==types[cidx]
  for ct in sizes[2:]:
   idx=0
   for _ in range(ct):
    d,p=uleb(b,p);idx+=d;af,p=uleb(b,p);co,p=uleb(b,p);assert idx<nm and methods[idx][0]==types[cidx]and co%4==0
    regs,ins,outs,tries,debug,nw=struct.unpack_from('<HHHHII',b,co);assert ins==len(methods[idx][3])+1 and regs>=ins
    w=struct.unpack_from('<'+'H'*nw,b,co+16);ip=0;boundaries=set();branches=[];invokes=0
    while ip<nw:
     boundaries.add(ip);v=w[ip];opcode=v&255;aa=v>>8;a=aa&15;bb=aa>>4;size=1;rs=[]
     if opcode in[0x0a,0x0c,0x0d,0x0f]:rs=[aa]
     elif opcode==0x0e:pass
     elif opcode==0x07:rs=[a,bb]
     elif opcode==0x12:rs=[a]
     elif opcode==0x13:rs=[aa];size=2
     elif opcode in[0x1a,0x22]:
      rs=[aa];size=2;assert w[ip+1]<(nstr if opcode==0x1a else nt)
     elif opcode==0x23:rs=[a,bb];size=2;assert w[ip+1]<nt
     elif opcode in[0x54,0x5b]:rs=[a,bb];size=2;assert w[ip+1]<nf
     elif opcode==0x4d:rs=[aa,w[ip+1]&255,w[ip+1]>>8];size=2
     elif opcode in[0x38,0x39,0x32,0x33,0x29]:
      size=2;rs=[]if opcode==0x29 else[a,bb]if opcode in[0x32,0x33]else[aa];offset=(w[ip+1]<<16>>16);offset=offset-65536 if offset>=32768 else offset;branches.append(ip+offset)
     elif opcode in[0x6e,0x6f,0x70,0x71,0x72,0x74]:
      size=3;mid=w[ip+1];assert mid<nm
      if opcode==0x74:cnt=aa;rs=list(range(w[ip+2],w[ip+2]+cnt))
      else:cnt=bb;packed=w[ip+2];rs=[packed&15,(packed>>4)&15,(packed>>8)&15,(packed>>12)&15,a][:cnt]
      assert cnt==len(methods[mid][3])+(0 if opcode==0x71 else 1),(methods[idx],methods[mid],cnt)
      assert cnt<=outs;invokes+=1
     else:raise AssertionError((methods[idx],ip,hex(opcode)))
     assert all(r<regs for r in rs),(methods[idx],ip,rs,regs)
     ip+=size
    assert ip==nw and all(x in boundaries for x in branches)
    if tries:
     tr=co+16+2*nw+(2 if nw%2 else 0);st,sz,ho=struct.unpack_from('<IHH',b,tr);assert st in boundaries and st+sz in boundaries
     n,cp=uleb(b,tr+8*tries);assert n==1;assert ho==cp-(tr+8*tries)
     cnt,cp=uleb(b,cp);assert cnt==1;tid,cp=uleb(b,cp);target,cp=uleb(b,cp);assert types[tid]=='Ljava/lang/Exception;'and target in boundaries and w[target]&255==0x0d
    defined.append({'class':types[cidx],'method':methods[idx][1],'code_units':nw,'invoke_count':invokes,'branch_targets_valid':True,'register_references_valid':True})
 assert js_annotations==1 and len(defined)==9
 mapoff=h[5];ct=struct.unpack_from('<I',b,mapoff)[0];items=[struct.unpack_from('<HHII',b,mapoff+4+i*12)for i in range(ct)];assert all(items[i][3]<=items[i+1][3]for i in range(ct-1))
 v={'dex_magic_and_checksums_valid':True,'string_type_method_reference_tables_valid':True,'defined_classes':nc,'defined_methods':defined,'javascript_interface_annotation_valid':True,'native_execution_tested':False}
 (ROOT/'build/dex_validation.json').write_text(json.dumps(v,indent=2));print(json.dumps(v,indent=2))
if __name__=='__main__':main()
