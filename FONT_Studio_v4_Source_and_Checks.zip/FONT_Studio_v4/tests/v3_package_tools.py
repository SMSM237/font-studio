"""Independent readers for the minimal Android resource package emitted by JS.
This is not an Android runtime; structural validation only.
"""
import struct, zipfile, io
U16=lambda b,p:struct.unpack_from('<H',b,p)[0]
U32=lambda b,p:struct.unpack_from('<I',b,p)[0]
def header(b,off):
    t,h,n=struct.unpack_from('<HHI',b,off)
    assert h>=8 and n>=h and off+n<=len(b)
    return t,h,n

def pool(b,off):
    t,h,n=header(b,off);assert t==1 and h>=28
    count,style,flags,start,styles=struct.unpack_from('<IIIII',b,off+8)
    assert not style and not styles and not flags&0x100
    out=[]
    for i in range(count):
        p=off+start+U32(b,off+h+4*i);num=U16(b,p);p+=2
        if num&0x8000:num=((num&0x7fff)<<16)|U16(b,p);p+=2
        assert p+num*2+2<=off+n and b[p+num*2:p+num*2+2]==b'\0\0'
        out.append(b[p:p+num*2].decode('utf-16le'))
    return out,n

def icon_resource(data,package):
    t,h,n=header(data,0);assert t==2 and h==12 and n==len(data) and U32(data,8)==1
    strings,s=pool(data,h);p=h+s
    pt,ph,pn=header(data,p);assert pt==0x200 and ph==288 and p+pn==len(data)
    assert U32(data,p+8)==0x7f
    label=data[p+12:p+268].decode('utf-16le').split('\0')[0];assert label==package
    type_off,last_type,key_off,last_key,type_offset=struct.unpack_from('<IIIII',data,p+268)
    types,ts=pool(data,p+type_off);keys,ks=pool(data,p+key_off)
    assert types==['drawable'] and keys==['font_logo'] and type_offset==0
    q=p+ph;spec=None;resolved={}
    while q<p+pn:
        typ,ch,cn=header(data,q)
        if typ==0x202:
            assert ch==16 and data[q+8]==1 and U32(data,q+12)==1;spec=True
        if typ==0x201:
            assert ch==84 and data[q+8]==1 and data[q+9]==0
            entries=U32(data,q+12);base=U32(data,q+16)
            assert entries==1 and base==ch+4 and U32(data,q+20)==64 and U16(data,q+34)==0xffff
            e=q+base+U32(data,q+ch);assert U16(data,e)==8 and U16(data,e+2)==0
            key=keys[U32(data,e+4)];assert key=='font_logo'
            assert U16(data,e+8)==8 and data[e+10]==0 and data[e+11]==3
            resolved[0x7f010000]=strings[U32(data,e+12)]
        q+=cn
    assert spec and q==p+pn and resolved=={0x7f010000:'res/drawable-nodpi/font_logo.png'}
    return resolved

def assert_stored_aligned(z,raw,name):
    i=z.getinfo(name);p=i.header_offset
    assert raw[p:p+4]==b'PK\x03\x04'
    start=p+30+U16(raw,p+26)+U16(raw,p+28)
    assert i.compress_type==zipfile.ZIP_STORED,name+' must be stored'
    assert start%4==0,(name,'not 4-byte aligned',start)
