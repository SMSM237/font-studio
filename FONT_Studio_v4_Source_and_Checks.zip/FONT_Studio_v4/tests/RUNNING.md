# Test execution

Tests use local font fixtures, never bundled fonts. `prepare_v3_fixtures.py` is retained as the fixture utility name only; it uses local DejaVu Sans, NanumSquare, GFS Artemisia, Cantarell Variable and the user's OPPO APK at `/mnt/data/OPPOBigClockSansShort.apk`. Do not package `build/tests/` or `build/private/`.

1. `python tests/prepare_v3_fixtures.py`
2. `node tests/test_v4_contract.cjs`
3. `python tests/test_v4_generic.py` (fontTools + FreeType + HarfBuzz independent geometry/shaping/raster checks)
4. `python tests/test_v4_variable_glyf.py` (gvar/native weight)
5. `python tests/test_studio_engine.py` (existing OPPO curves + 5778 time strings)
6. `node tests/test_v4_import_names.cjs`
7. `python src/build_ui.py`
8. `python tests/test_v4_ui.py` (Playwright / `/usr/bin/chromium`, actual local JS importer/editor + FontFace / Canvas)
9. `python tests/test_v4_packages.py`
10. `python src/build_all.py dist/FONT_Studio_v4.apk`

Browser test navigation is restricted by the test environment. The page is loaded via `set_content`; test-only SHA/signing RPCs delegate to real Python/Node cryptography. They are absent from the shipped app. The native file-picker save call is captured, not claimed to have run on Android. Final package tests inspect the real DEX bridge, manifest, icon resource, ZIP alignment, v1 and v2 signatures.

The independent mark-position test covers only glyphs present in each source. NanumSquare lacks U+0301: HarfBuzz synthesizes a .notdef position for it, so that missing-mark sample is not used as a font positioning reference. CFF2 reference paths are evaluated at the variable location directly instead of serializing a static CFF first, since the latter rounds relative operands and accumulates extra quantization.
