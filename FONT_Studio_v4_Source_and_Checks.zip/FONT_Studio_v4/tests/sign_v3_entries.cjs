// Run the real signing implementation under Node's WebCrypto for headless tests.
const fs=require('fs');const E=require('../assets/engine.js');global.crypto=require('crypto').webcrypto;
const keyFile=process.argv[2];let saved={};if(fs.existsSync(keyFile))saved=JSON.parse(fs.readFileSync(keyFile));
global.localStorage={getItem:k=>saved[k]??null,setItem:(k,v)=>{saved[k]=v;fs.writeFileSync(keyFile,JSON.stringify(saved))}};
let input='';process.stdin.on('data',s=>input+=s);process.stdin.on('end',async()=>{try{const e=JSON.parse(input).map(([n,b])=>[n,new Uint8Array(b)]);const a=await E.signApk(e);process.stdout.write(Buffer.from(a).toString('base64'))}catch(e){console.error(e);process.exit(1)}});
