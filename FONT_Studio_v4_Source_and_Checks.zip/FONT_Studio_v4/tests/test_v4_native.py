from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from android_binary import decode_manifest
x=json.loads((ROOT/'build/dex_audit.json').read_text());m=next(m for m in x['methods']if m['ref'][1]=='saveApk')
assert m['ref'][2]==['Ljava/lang/String;','Ljava/lang/String;'],'Native.saveApk must accept the user filename, not a constant'
assert 'outputName' in x['strings'],'native pending filename field missing'
assert not any('EdgeTallStudio_Clock.apk' in s for s in x['strings']),'native UI still uses the hardcoded old name'
r=decode_manifest((ROOT/'build/AndroidManifest.xml').read_bytes());a=r.find('application');ns='{http://schemas.android.com/apk/res/android}'
assert r.get('package')=='app.fontstudio.editor4'
assert a.get(ns+'label')=='FONT Studio 4'
assert a.get(ns+'icon')==str(0x7f010000),'approved logo not referenced as a real app icon'
assert (ROOT/'build/resources.arsc').exists()
print('Native dynamic filename, app label and launcher icon contracts passed.')
