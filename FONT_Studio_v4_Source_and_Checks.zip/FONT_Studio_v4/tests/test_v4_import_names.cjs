/* Regressions: exact-hash-only input, hardcoded label/name, single package ID,
 * corrupted Unicode and changed glyph bytes must all be detected. */
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),out=path.join(root,'build/tests');
global.crypto=require('crypto').webcrypto;
const stored=new Map();global.localStorage={getItem:k=>stored.has(k)?stored.get(k):null,setItem:(k,v)=>stored.set(k,v)};
const p=path.join(root,'assets/font-studio.js'),S=fs.existsSync(p)?require(p):require('../assets/engine.js');
assert.equal(typeof S.importFiles,'function','generic importer missing');
const E=require('../assets/engine.js'),read=f=>new Uint8Array(fs.readFileSync(path.join(out,f)));
(async()=>{
 let count=0;const check=(c,m)=>{assert.ok(c,m);count++},report={};
 const a=await S.importFiles(read('latin.ttf'),'Latin.ttf');check(a.length===1,'one TTF');check(a[0].mode==='editable','generic editable mode');
 const b=await S.importFiles(read('cff.otf'),'CFF.otf');check(b[0].extension==='.otf','CFF extension');
 const c=await S.importFiles(read('twofaces.ttc'),'twofaces.ttc');check(c.length===2,'TTC face selection');
 const otc=await S.importFiles(read('twofaces.otc'),'twofaces.otc');check(otc.length===2&&otc.every(f=>f.extension==='.otf'),'OTC CFF face selection');
 const d=await S.importFiles(read('multi.apk'),'multi.apk');check(d.length===2,'APK picks fonts not code');
 const o=await S.importFiles(read('oppo.ttf'),'OPPO.ttf');check(o[0].mode==='oppo','preserve B editor');
 const cv=await S.importFiles(read('cffvar.otf'),'variable.otf');check(cv[0].variable,'variable preserved as original');
 for(const bad of ['','   ','../a','a/b','a\\b','A\u0000B','x'.repeat(49),'test.apk','abc\u202Etxt'])assert.throws(()=>S.validateName(bad)),count++;
 const label='나의 시계 & Edge 01';check(S.validateName(label)===label,'Korean label preserved');
 const id=await S.identityForName(label),id2=await S.identityForName('다른 시계');check(id.packageName!==id2.packageName,'distinct names coexist');check((await S.identityForName(label)).packageName===id.packageName,'same label stable update');
 const version1=S.nextVersion(id.packageName),version2=S.nextVersion(id.packageName);check(version2>version1,'monotonic version');
 for(const [tag,font]of [['latin',a[0]],['hangul',c[1]],['cff',b[0]],['cffvar',cv[0]],['oppo',o[0]]]){
  const raw=font.mode==='oppo'?E.instantiate(font.bytes,{...E.DEFAULTS}):font.bytes;
  const named=S.fontNamed(raw,label,id.postScriptName);check(E.checksum(named)===0xb1b0afba,'checksum '+tag);
  const before=S.parse(raw),after=S.parse(named);
  for(const[k,v]of before.tables)if(!['name','head','DSIG'].includes(k))check(Buffer.from(v).equals(Buffer.from(after.tables.get(k))),'preserve '+tag+' '+k);
  const names=S.readNames(after.tables.get('name'));
  for(const n of [1,4,16,18,21])check(names[n]===label,'internal name '+tag+' '+n);
  check(names[6]===id.postScriptName,'PostScript safe');
  fs.writeFileSync(path.join(out,tag+'-renamed'+font.extension),named);
  const entries=S.packageEntries(named,{name:label,identity:id,version:tag==='oppo'?version2:version1,settings:{...E.DEFAULTS},logo:new Uint8Array(fs.readFileSync(path.join(root,'res/drawable-nodpi/font_logo.png')))});
  check(!entries.some(([n])=>n==='classes.dex'),'no executable source code');
  const apk=await E.signApk(entries);fs.writeFileSync(path.join(out,tag+'-result.apk'),apk);
  report[tag]={extension:font.extension,bytes:named.length,label,package:id.packageName,sha256:E.hex(await E.digest(named))};
 }
 const zero=E.instantiate(o[0].bytes,{...E.DEFAULTS,leadingZero:true});const zeroNamed=S.fontNamed(zero,label,id.postScriptName);fs.writeFileSync(path.join(out,'oppo-zero.ttf'),zeroNamed);check(S.parse(zeroNamed).tables.has('GSUB'),'GSUB zero preserved after rename');
 for(const bad of [new Uint8Array(20),Uint8Array.of(119,79,70,70,0,0,0,0)]){await assert.rejects(()=>S.importFiles(bad,'bad.woff'));count++}
 const badFont=read('latin.ttf');badFont[12+8]=255;await assert.rejects(()=>S.importFiles(badFont,'damaged.ttf'));count++;
 const checks={assertions:count,fonts:report,genericOriginalGlyphTablesUnchanged:true,variableTablesPreserved:true,unicodeNamesVerified:true,physicalDeviceTested:false};
 fs.writeFileSync(path.join(root,'build/v4_import_name_validation.json'),JSON.stringify(checks,null,2));console.log(JSON.stringify(checks,null,2));
})().catch(e=>{console.error(e);process.exit(1)});
