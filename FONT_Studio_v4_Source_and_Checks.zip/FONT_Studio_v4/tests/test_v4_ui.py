"""Actual Chromium file-input, name, mode, preview and payload tests.
Android picker/ART are NOT claimed to be exercised by this test.
"""
from pathlib import Path
import json,base64,zipfile,hashlib,subprocess
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'build/tests'
def main():
 with sync_playwright()as p:
  print('START',flush=True)
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  context=browser.new_context(viewport={'width':412,'height':915},device_scale_factor=2,accept_downloads=True)
  context.route('https://appassets.androidplatform.net/**',lambda route:route.fulfill(status=200,content_type='text/html',body=(ROOT/'assets/index.html').read_text()))
  page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  # Navigation is policy-blocked in this container. Keep UI/rendering real and
  # delegate SHA-256 and signing to real Python/Node crypto, not fake signatures.
  page.expose_function('qaDigest',lambda arr:list(hashlib.sha256(bytes(arr)).digest()))
  def sign_entries(entries):
   print('SIGN starting',len(entries),flush=True)
   r=subprocess.run(['node',str(ROOT/'tests/sign_v3_entries.cjs'),str(OUT/'qa-signing-private.json')],input=json.dumps(entries),capture_output=True,text=True,check=True)
   print('SIGN complete',flush=True);return r.stdout
  page.expose_function('qaSignEntries',sign_entries)
  shim="""<script>
  Object.defineProperty(crypto,'subtle',{value:{digest:async(alg,a)=>new Uint8Array(await qaDigest(Array.from(new Uint8Array(a.buffer||a,a.byteOffset||0,a.byteLength)))).buffer},configurable:true});
  const testStore=new Map();Object.defineProperty(window,'localStorage',{value:{getItem:k=>testStore.has(k)?testStore.get(k):null,setItem:(k,v)=>testStore.set(k,v)},configurable:true});
  </script>"""
  page.set_content(shim+(ROOT/'assets/index.html').read_text())
  assert page.locator('#fontName').count()==1,'Output font/app name input is missing'
  page.evaluate("()=>{EdgeB.signApk=async entries=>EdgeB.unb64(await qaSignEntries(entries.map(([n,b])=>[n,Array.from(b)])))}")
  assert page.locator('#brandLogo').is_visible(),'Approved FONT logo not in UI'
  assert page.evaluate('!!crypto.subtle')
  page.evaluate('()=>{window.Native={saveApk:(b,n)=>{window.captured={base64:b,name:n}}}}')
  print("CHECK page.locator('#input').set_input_files(str(OUT/'oppo.ttf'))",flush=True);page.locator('#input').set_input_files(str(OUT/'oppo.ttf'));page.wait_for_function('()=>Studio.ready()')
  assert not page.locator('#weight').is_disabled();baseline=page.evaluate('Studio.metrics()')
  for key,value in [('width','120'),('height','115'),('weight','350'),('spacing','4')]:
   old=page.evaluate('EdgeB.b64(Studio.fontBytes())');page.locator('#'+key).fill(value);page.wait_for_function('()=>Studio.ready()');assert old!=page.evaluate('EdgeB.b64(Studio.fontBytes())'),key
  page.locator('#zero').check();page.wait_for_function('()=>Studio.ready()');assert page.evaluate('Studio.zeroVerified()')
  assert page.locator('#sampleText').input_value()=='8:45'
  label='나의 시계 & Edge 01';page.locator('#fontName').fill(label);page.wait_for_function('()=>Studio.ready()')
  previewBytes=page.evaluate('EdgeB.b64(Studio.fontBytes())')
  print("CHECK page.locator('#build').click();page.wait_for_function('()=>!!window.capture",flush=True);page.locator('#build').click();page.wait_for_function('()=>!!window.captured',timeout=30000)
  captured=page.evaluate('window.captured');assert captured['name']==label+'.apk','Native filename differs'
  (OUT/'ui-oppo.apk').write_bytes(base64.b64decode(captured['base64']))
  with zipfile.ZipFile(OUT/'ui-oppo.apk')as z:
   fontPath=next(n for n in z.namelist()if n.startswith('assets/fonts/'));assert z.read(fontPath)==base64.b64decode(previewBytes),'preview and APK font differ'
  page.evaluate('nativeSaved()');assert label+'.apk' in page.locator('#saved').inner_text()
  # Invalid names must disable build; changing a name must invalidate old bytes.
  page.locator('#fontName').fill('a/b');page.wait_for_timeout(300);assert page.locator('#build').is_disabled()
  page.locator('#fontName').fill('다른 시계');page.wait_for_function('()=>Studio.ready()');assert page.locator('#saved').is_hidden()
  page.locator('#reset').click();page.wait_for_function('()=>Studio.ready()');assert page.evaluate('Studio.metrics().width')==baseline['width']
  # Generic TTF must keep all original letters and edit real outlines, not fake controls.
  print("CHECK page.locator('#input').set_input_files(str(OUT/'hangul.ttf'))",flush=True);page.locator('#input').set_input_files(str(OUT/'hangul.ttf'));page.wait_for_function('()=>Studio.ready()')
  assert not page.locator('#weight').is_disabled() and not page.locator('#width').is_disabled();assert '실제 윤곽선' in page.locator('#modeName').inner_text()
  assert page.locator('#weight').input_value()=='0'
  assert page.locator('#zero').is_disabled()
  generic_initial=page.evaluate('EdgeB.b64(Studio.fontBytes())')
  for key,value in [('width','85'),('height','125'),('weight','6'),('spacing','2')]:
   old=page.evaluate('EdgeB.b64(Studio.fontBytes())');page.locator('#'+key).fill(value);page.wait_for_function('()=>Studio.ready()',timeout=30000);assert old!=page.evaluate('EdgeB.b64(Studio.fontBytes())'),key+' has no real effect on generic font'
  page.locator('#reset').click();page.wait_for_function('()=>Studio.ready()',timeout=30000);assert generic_initial==page.evaluate('EdgeB.b64(Studio.fontBytes())'),'Reset must restore exact source geometry'
  page.locator('#height').fill('125');page.wait_for_function('()=>Studio.ready()',timeout=30000)
  page.locator('#weight').fill('6');page.wait_for_function('()=>Studio.ready()',timeout=30000)
  page.locator('#sampleText').fill('가나다 FONT 123');page.wait_for_timeout(200);assert page.locator('#sampleError').inner_text()==''
  page.locator('#fontName').fill('나의 한글 폰트');page.wait_for_function('()=>Studio.ready()')
  genericPreviewBytes=page.evaluate('EdgeB.b64(Studio.fontBytes())')
  page.evaluate('window.captured=null');print("CHECK page.locator('#build').click();page.wait_for_function('()=>!!window.capture",flush=True);page.locator('#build').click();page.wait_for_function('()=>!!window.captured',timeout=30000)
  captured=page.evaluate('window.captured');(OUT/'ui-hangul.apk').write_bytes(base64.b64decode(captured['base64']));assert captured['name']=='나의 한글 폰트.apk'
  with zipfile.ZipFile(OUT/'ui-hangul.apk') as z:
   fontPath=next(n for n in z.namelist()if n.startswith('assets/fonts/'));assert z.read(fontPath)==base64.b64decode(genericPreviewBytes),'generic preview and APK font differ'
  page.evaluate('nativeSaveCancelled()');assert not page.locator('#build').is_disabled()
  # Import a collection and change the selected face.
  print("CHECK page.locator('#input').set_input_files(str(OUT/'twofaces.ttc'))",flush=True);page.locator('#input').set_input_files(str(OUT/'twofaces.ttc'));page.wait_for_function('()=>Studio.ready()')
  assert page.locator('#faceSelect option').count()==2;before=page.evaluate('EdgeB.b64(Studio.fontBytes())')
  page.locator('#faceSelect').select_option('1');page.wait_for_function('()=>Studio.ready()');assert before!=page.evaluate('EdgeB.b64(Studio.fontBytes())')
  page.locator('#input').set_input_files(str(OUT/'twofaces.otc'));page.wait_for_function('()=>Studio.ready()');assert page.locator('#faceSelect option').count()==2
  page.locator('#faceSelect').select_option('1');page.wait_for_function('()=>Studio.ready()')
  # OTF and multi-font APK imports go through real File input and decompression.
  print("CHECK page.locator('#input').set_input_files(str(OUT/'cff.otf'))",flush=True);page.locator('#input').set_input_files(str(OUT/'cff.otf'));page.wait_for_function('()=>Studio.ready()');assert not page.locator('#weight').is_disabled()
  page.locator('#width').fill('90');page.locator('#height').fill('130');page.locator('#weight').fill('5');page.wait_for_function('()=>Studio.ready()',timeout=30000)
  page.locator('#input').set_input_files(str(OUT/'multi.apk'));page.wait_for_function('()=>Studio.ready()');assert page.locator('#faceSelect option').count()==2
  page.locator('#faceSelect').select_option('1');page.wait_for_function('()=>Studio.ready()')
  print("CHECK page.locator('#input').set_input_files(str(OUT/'cffvar.otf'))",flush=True);page.locator('#input').set_input_files(str(OUT/'cffvar.otf'));page.wait_for_function('()=>Studio.ready()',timeout=30000)
  assert page.locator('#weight').input_value()=='400';assert page.locator('#weight').get_attribute('max')=='800'
  old=page.evaluate('EdgeB.b64(Studio.fontBytes())');page.locator('#weight').fill('650');page.wait_for_function('()=>Studio.ready()',timeout=30000);assert old!=page.evaluate('EdgeB.b64(Studio.fontBytes())')
  # Corrupt input clears stale previews and build state.
  (OUT/'broken.ttf').write_bytes(b'not a font');page.locator('#input').set_input_files(str(OUT/'broken.ttf'));page.wait_for_timeout(400);assert page.locator('#build').is_disabled();assert page.locator('#empty').is_visible()
  # Final real UI screenshots using user's input font, never packaged into the app.
  page.locator('#input').set_input_files(str(OUT/'latin.ttf'));page.wait_for_function('()=>Studio.ready()',timeout=30000)
  page.locator('#fontName').fill('나의 편집 폰트');page.locator('#height').fill('130');page.locator('#weight').fill('8');page.wait_for_function('()=>Studio.ready()',timeout=30000);page.evaluate('scrollTo(0,0)')
  print("CHECK page.screenshot(path=str(ROOT/'build/FONT_Studio_v4_preview.png'))",flush=True);page.screenshot(path=str(ROOT/'build/FONT_Studio_v4_preview.png'))
  page.locator('#fontName').scroll_into_view_if_needed();page.screenshot(path=str(ROOT/'build/FONT_Studio_v4_names.png'))
  page.screenshot(path=str(ROOT/'build/FONT_Studio_v4_full.png'),full_page=True)
  for w in [360,390,412,480,768]:
   page.set_viewport_size({'width':w,'height':915});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),'Horizontal overflow '+str(w)
  assert not errors,errors
  report={'browser':browser.version,'realFileImports':['ttf','otf','ttc','otc','multi-font APK'],'OPPOEditorPreserved':True,'ordinaryFontsActuallyEdited':True,'UnicodeOutputNameMatchesNativeSave':True,'PreviewBytesEqualAPKFont':True,'GenericPreviewBytesEqualAPKFont':True,'ApprovedLogoVisible':True,'LeadingZeroShapedInBrowser':True,'TTFandOTFandCFF2ActualEditing':True,'StaleBuildBlocked':True,'NoHorizontalOverflow':True,'javascriptErrors':errors,'AndroidARTOrSamsungTested':False}
  (ROOT/'build/v4_ui_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2));browser.close()
if __name__=='__main__':main()
