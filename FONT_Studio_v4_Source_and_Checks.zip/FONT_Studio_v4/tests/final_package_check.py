"""Verify the shipped FONT Studio builder, with no included font or private key."""
from pathlib import Path
import sys,zipfile,hashlib,json,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from android_binary import decode_manifest
from test_apk_signature import verify_v2
from v3_package_tools import icon_resource,assert_stored_aligned
p=Path(sys.argv[1])if len(sys.argv)>1 else ROOT/'dist/FONT_Studio_v4.apk'
ns='{http://schemas.android.com/apk/res/android}';raw=p.read_bytes()
with zipfile.ZipFile(p)as z:
    assert z.testzip()is None
    expected={'AndroidManifest.xml','resources.arsc','classes.dex','assets/index.html','res/drawable-nodpi/font_logo.png'}
    actual={n for n in z.namelist()if not n.startswith('META-INF/')}
    assert actual==expected,('builder contents',actual^expected)
    for n,loc in [('AndroidManifest.xml','build/AndroidManifest.xml'),('resources.arsc','build/resources.arsc'),('classes.dex','build/classes.dex'),('assets/index.html','assets/index.html'),('res/drawable-nodpi/font_logo.png','res/drawable-nodpi/font_logo.png')]:
        assert z.read(n)==(ROOT/loc).read_bytes(),n
    doc=decode_manifest(z.read('AndroidManifest.xml'));app=doc.find('application')
    assert doc.get('package')=='app.fontstudio.editor4'
    assert doc.get(ns+'versionName')=='4.0'and doc.get(ns+'versionCode')=='4'
    assert app.get(ns+'label')=='FONT Studio 4'and app.get(ns+'icon')==str(0x7f010000)
    assert not doc.findall('uses-permission')and app.get(ns+'allowBackup')=='false'
    assert len(app.findall('activity'))==1 and not any(app.findall(t)for t in ['service','receiver','provider'])
    icon_resource(z.read('resources.arsc'),doc.get('package'))
    for n in ['resources.arsc','classes.dex']:assert_stored_aligned(z,raw,n)
    for n in z.namelist():assert not n.lower().endswith(('.ttf','.otf','.woff','.woff2','.ttc','.otc','.p12','.pem','.keystore'))
    html=z.read('assets/index.html').decode()
    for marker in ['id="fontName"','id="brandLogo"','const GenericEditor=', 'const FontkitLocal=', 'const FontStudio=','const Studio=','Native.saveApk(EdgeB.b64(finalApk),lastBuiltIdentity.fileName)']:
        assert marker in html,marker
    for unwanted in ['qaDigest','qaSignEntries','testStore','data:font','data:application/font','BEGIN PRIVATE KEY']:
        assert unwanted not in html,unwanted
    assert '/*ENGINE*/'not in html and '/*UIJS*/'not in html and '/*FONTSTUDIO*/'not in html
    (ROOT/'build/helper_manifest.xml').write_text(ET.tostring(doc,encoding='unicode'),encoding='utf-8')
sig=verify_v2(p)
report={'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(raw).hexdigest(),'app_label':'FONT Studio 4','package':'app.fontstudio.editor4','version':'4.0','approved_icon_resource_resolves':True,'contents_match_sources':True,'font_files_included':False,'signing_private_keys_included':False,'test_shims_in_production':False,'permissions':[],'source_apk_executed':False,'v2_signature_valid':sig['v2_signature_valid'],'zip_crc_valid':True,'physical_android_or_samsung_tested':False}
(ROOT/'build/final_package_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
