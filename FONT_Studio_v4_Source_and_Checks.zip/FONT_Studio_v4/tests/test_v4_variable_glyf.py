"""Use the user's source locally under a different name to exercise generic gvar,
not the exact-hash OPPO-only fast path. No font is included in the source archive.
"""
from pathlib import Path
import json,subprocess
from fontTools.ttLib import TTFont
from fontTools.pens.boundsPen import BoundsPen
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'build/tests'
src=OUT/'qa-variable-glyf.ttf'
f=TTFont(OUT/'oppo.ttf');f['name'].setName('Local QA Variable',1,3,1,0x409);f.save(src)
checks=[]
for weight in [150,500,800]:
 dst=OUT/f'qa-variable-glyf-{weight}.ttf'
 subprocess.run(['node',str(ROOT/'tests/export_v4.cjs'),str(src),json.dumps({'weight':weight,'width':120,'height':110}),str(dst)],check=True,capture_output=True,text=True)
 a=TTFont(src);b=TTFont(dst);ga=a.getGlyphSet(location={'wght':weight});gb=b.getGlyphSet();assert 'fvar'not in b
 for ch in '0123456789:':
  x=BoundsPen(ga);y=BoundsPen(gb);ga[a.getBestCmap()[ord(ch)]].draw(x);gb[b.getBestCmap()[ord(ch)]].draw(y)
  expected=[x.bounds[0]*1.2,x.bounds[1]*1.1,x.bounds[2]*1.2,x.bounds[3]*1.1]
  error=max(abs(p-q)for p,q in zip(expected,y.bounds));assert error<3,(weight,ch,error,expected,y.bounds)
  checks.append({'weight':weight,'character':ch,'maxCoordinateErrorUnits':error})
(ROOT/'build/v4_variable_glyf_validation.json').write_text(json.dumps({'tests':len(checks),'allPassed':True,'details':checks},indent=2));print('Generic variable TrueType: all',len(checks),'coordinate checks passed')
