const fs=require('fs'),e=require('../assets/engine.js');
(async()=>{let src=await e.extract(new Uint8Array(fs.readFileSync(process.argv[2]))),f=e.instantiate(src);fs.writeFileSync(process.argv[3],f);console.log(JSON.stringify({length:f.length,checksum:e.checksum(f),sha:e.hex(await e.digest(f))}))})().catch(e=>{console.error(e);process.exit(1)});
