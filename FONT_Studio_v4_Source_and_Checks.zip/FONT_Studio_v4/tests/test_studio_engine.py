"""Regression and feature acceptance checks. No font binary is distributed.
Mutation contracts: ignoring weight/width/height/spacing must fail geometry checks;
omitting GSUB must fail actual HarfBuzz shaping, not a string-formatting mock.
"""
from pathlib import Path
import io, json, subprocess, zipfile, math, ctypes as C, ctypes.util
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
ROOT=Path(__file__).resolve().parents[1]
SRC=Path('/mnt/data/OPPOBigClockSansShort.apk')
OUT=ROOT/'build/tests';OUT.mkdir(parents=True,exist_ok=True)

class Info(C.Structure):
    _fields_=[('codepoint',C.c_uint32),('mask',C.c_uint32),('cluster',C.c_uint32),('var1',C.c_uint32),('var2',C.c_uint32)]
class Pos(C.Structure):
    _fields_=[('x_advance',C.c_int32),('y_advance',C.c_int32),('x_offset',C.c_int32),('y_offset',C.c_int32),('var',C.c_uint32)]
class HB:
    def __init__(self,data):
        lib=C.CDLL(ctypes.util.find_library('harfbuzz'))
        for name,restype,argtypes in [
            ('hb_blob_create',C.c_void_p,[C.c_void_p,C.c_uint,C.c_int,C.c_void_p,C.c_void_p]),
            ('hb_face_create',C.c_void_p,[C.c_void_p,C.c_uint]),('hb_font_create',C.c_void_p,[C.c_void_p]),
            ('hb_ot_font_set_funcs',None,[C.c_void_p]),('hb_buffer_create',C.c_void_p,[]),
            ('hb_buffer_add_utf8',None,[C.c_void_p,C.c_char_p,C.c_int,C.c_uint,C.c_int]),
            ('hb_buffer_guess_segment_properties',None,[C.c_void_p]),
            ('hb_shape',None,[C.c_void_p,C.c_void_p,C.c_void_p,C.c_uint]),
            ('hb_buffer_get_glyph_infos',C.POINTER(Info),[C.c_void_p,C.POINTER(C.c_uint)]),
            ('hb_buffer_get_glyph_positions',C.POINTER(Pos),[C.c_void_p,C.POINTER(C.c_uint)]),
            ('hb_blob_destroy',None,[C.c_void_p]),('hb_face_destroy',None,[C.c_void_p]),('hb_font_destroy',None,[C.c_void_p]),('hb_buffer_destroy',None,[C.c_void_p]),
        ]:
            f=getattr(lib,name);f.restype=restype;f.argtypes=argtypes
        self.lib=lib;self.data=C.create_string_buffer(data)
        blob=lib.hb_blob_create(self.data,len(data),0,None,None)
        face=lib.hb_face_create(blob,0);self.font=lib.hb_font_create(face)
        lib.hb_ot_font_set_funcs(self.font);lib.hb_face_destroy(face);lib.hb_blob_destroy(blob)
    def shape(self,text):
        l=self.lib;b=l.hb_buffer_create();s=text.encode();l.hb_buffer_add_utf8(b,s,len(s),0,-1);l.hb_buffer_guess_segment_properties(b);l.hb_shape(self.font,b,None,0)
        n=C.c_uint();i=l.hb_buffer_get_glyph_infos(b,C.byref(n));p=l.hb_buffer_get_glyph_positions(b,C.byref(n))
        out=[(i[k].codepoint,p[k].x_advance,p[k].x_offset,p[k].y_offset) for k in range(n.value)];l.hb_buffer_destroy(b);return out
    def close(self):self.lib.hb_font_destroy(self.font)

def rnd(x):return math.floor(x+0.5)
def read_source():
    with zipfile.ZipFile(SRC) as z:return z.read('assets/fonts/LOCKSCREENOPPOBigClockShort.ttf')

def main():
    configs={'baseline':{},'width':{'width':125},'height':{'height':130},'space':{'spacing':15},'zero':{'leadingZero':True},'all':{'width':115,'height':120,'spacing':-10,'weight':350,'leadingZero':True},
             'invalid_weight':{'weight':1001},'invalid_width':{'width':0},'invalid_height':{'height':'NaN'},'invalid_spacing':{'spacing':999},'invalid_zero':{'leadingZero':'true'}}
    for w in [0,100,250,350,500,650,750,900,1000]:configs[f'w{w}']={'weight':w}
    (OUT/'configs.json').write_text(json.dumps(configs))
    result=json.loads(subprocess.check_output(['node',str(ROOT/'tests/batch_engine.cjs'),str(SRC),str(OUT/'configs.json'),str(OUT)],text=True))
    failures=[];checks=[]
    def check(ok,label):
        checks.append({'check':label,'passed':bool(ok)})
        if not ok:failures.append(label)
    raw=read_source()
    for item in result:
        name=item['name'];o=configs[name]
        if name.startswith('invalid_'):
            check(not item['ok'],name+' rejected');continue
        if not item['ok']:check(False,name+': '+item['error']);continue
        check(item['checksum']==0xb1b0afba,name+' checksum')
        out=TTFont(OUT/(name+'.ttf'))
        ref=instantiateVariableFont(TTFont(io.BytesIO(raw)),{'HGHT':900,'wght':o.get('weight',500)},inplace=False)
        # Static TTF serialization rounds the variable outlines before the requested scale.
        buffer=io.BytesIO();ref.save(buffer);ref=TTFont(io.BytesIO(buffer.getvalue()))
        sx=o.get('width',100)/100;sy=o.get('height',100)/100;sp=o.get('spacing',0)*ref['head'].unitsPerEm/100
        matches=True;mm=True
        for gn in ref.getGlyphOrder():
            a,b=ref['glyf'][gn],out['glyf'][gn]
            tracking=sp if gn not in ['.notdef','space'] else 0
            if a.numberOfContours:
                matches &= list(b.coordinates)==[(rnd(x*o.get('width',100)/100+tracking/2),rnd(y*o.get('height',100)/100)) for x,y in a.coordinates]
                matches &= list(a.endPtsOfContours)==list(b.endPtsOfContours) and list(a.flags)==list(b.flags)
            aw,lsb=ref['hmtx'][gn]
            mm &= out['hmtx'][gn]==(rnd(aw*o.get('width',100)/100+tracking),rnd(lsb*o.get('width',100)/100+tracking/2))
        check(matches,name+' original curves + width/height/spacing')
        check(mm,name+' advances and side bearings')
        check(('GSUB' in out)==o.get('leadingZero',False),name+' zero GSUB option')
    # Real shaper acceptance: output glyph IDs and advances equal a normally padded string.
    shapes=0
    for name in ['zero','all']:
        if not (OUT/(name+'.ttf')).exists():continue
        h=HB((OUT/(name+'.ttf')).read_bytes());font=TTFont(OUT/(name+'.ttf'));cm=font.getBestCmap();ids={chr(cp):font.getGlyphID(gn)for cp,gn in cm.items()}
        passed=True
        for hour in range(24):
            for minute in range(60):
                for hr in [hour,(hour%12 or 12)]:
                    s=f'{hr}:{minute:02}';expected=f'{hr:02}:{minute:02}'
                    actual=h.shape(s);reference=h.shape(expected)
                    passed &= actual==reference and [r[0]for r in actual]==[ids[ch]for ch in expected]
                    shapes+=1
        for s in ['10:45','11:11','08:45','23:59','0123456789','9','45','99:99','8:45:07']:
            expected='08:45:07' if s=='8:45:07' else s
            passed &= [r[0]for r in h.shape(s)]==[ids[ch]for ch in expected];shapes+=1
        check(passed,name+' HarfBuzz 24h/12h + boundaries');h.close()
    report={'checks':checks,'shaped_strings':shapes,'failures':failures,'android_device_tested':False}
    (ROOT/'build/studio_engine_validation.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({'checks':len(checks),'shaped_strings':shapes,'failures':failures},indent=2))
    assert not failures,failures
if __name__=='__main__':main()
