const fs=require('fs'), e=require('../assets/engine.js');
(async()=>{
  const src=await e.extract(fs.readFileSync(process.argv[2]));
  const configs=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
  const result=[];
  for(const [name,options] of Object.entries(configs)){
    try {const f=e.instantiate(src,options);fs.writeFileSync(`${process.argv[4]}/${name}.ttf`,f);result.push({name,ok:true,checksum:e.checksum(f)});}
    catch(err){result.push({name,ok:false,error:err.message});}
  }
  console.log(JSON.stringify(result));
})().catch(err=>{console.error(err);process.exit(1)});
