const assert=require('node:assert/strict'), fs=require('node:fs'), path=require('node:path');
const root=path.resolve(__dirname,'..');
const F=require('../assets/font-studio.js');
(async()=>{
const [f]=await F.importFiles(fs.readFileSync(path.join(root,'build/tests/latin.ttf')),'latin.ttf');
assert.equal(f.mode,'editable','Ordinary TrueType must be editable, not original-only');
assert.equal(typeof F.editFont,'function','A real generic font editing pipeline must be present');
})().catch(e=>{console.error(e);process.exit(1)});
