"""Independent output checks using fontTools, FreeType/Pillow and HarfBuzz.
All font fixtures/output are LOCAL ONLY; exclude build/tests from distribution.
"""
from pathlib import Path
import json,subprocess,io,math
from fontTools.ttLib import TTFont
from fontTools.pens.boundsPen import BoundsPen
from fontTools.varLib.instancer import instantiateVariableFont
from PIL import Image,ImageDraw,ImageFont
from test_studio_engine import HB
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'build/tests';checks=[]
def check(ok,n):
 checks.append({'name':n,'passed':bool(ok)})
 if not ok: raise AssertionError(n)
def convert(src,opts,name):
 out=OUT/(name+'.ttf')
 subprocess.run(['node',str(ROOT/'tests/export_v4.cjs'),str(src),json.dumps(opts),str(out)],check=True,capture_output=True,text=True,timeout=30)
 return out

def bound(f,g):
 if not hasattr(f,'_qa_glyphset'):f._qa_glyphset=f.getGlyphSet()
 p=BoundsPen(f._qa_glyphset);f._qa_glyphset[g].draw(p);return p.bounds

def render(p,text,size=500):
 f=ImageFont.truetype(str(p),size)
 im=Image.new('L',(4000,1800));d=ImageDraw.Draw(im);d.text((100,800),text,font=f,fill=255,anchor='ls');bb=im.getbbox();return im,bb

fixtures=[('latin.ttf','FONT 8:45 café'),('hangul.ttf','가나다 FONT 8:45'),('cff.otf','FONT 8:45')]
outputs=[]
for filename,text in fixtures:
 src=OUT/filename;base=TTFont(src)
 normal=convert(src,{},'qa-'+filename+'-base')
 check(normal.read_bytes()==src.read_bytes(),filename+' neutral exact bytes')
 dst=convert(src,{'width':125,'height':120},'qa-'+filename+'-scaled');f=TTFont(dst)
 check(f['maxp'].numGlyphs==base['maxp'].numGlyphs,filename+' every glyph retained')
 c1=base.getBestCmap();c2=f.getBestCmap();check(set(c1)==set(c2),filename+' entire Unicode coverage')
 check('glyf'in f and 'CFF 'not in f,filename+' editable static TrueType result')
 for ch in text:
  if ch.isspace():continue
  a=bound(base,c1[ord(ch)]);b=bound(f,c2[ord(ch)]);
  check(all(abs(v-t)<2 for v,t in zip(b,[a[0]*1.25,a[1]*1.2,a[2]*1.25,a[3]*1.2])),filename+' outline scaling '+ch)
 h1=HB(src.read_bytes());h2=HB(dst.read_bytes())
 for sample in [text,'AVATAR To fi office','A\u0301','x\u0301','q\u0308']:
  # Missing combining marks are .notdef with HarfBuzz synthesized fallback offsets,
  # not positioning encoded in this font. Compare only supported text here.
  if any(ord(ch) not in c1 for ch in sample): continue
  a=h1.shape(sample);b=h2.shape(sample);check([p[0]for p in a]==[p[0]for p in b],filename+' substitutions retained '+sample)
  check(all(abs(pb[1]-pa[1]*1.25)<=3 for pa,pb in zip(a,b)),filename+' advances/kerning scaled '+sample)
  check(all(abs(pb[2]-pa[2]*1.25)<=3 and abs(pb[3]-pa[3]*1.2)<=3 for pa,pb in zip(a,b)),filename+' positioning scaled '+sample)
 h1.close();h2.close()
 dark=convert(src,{'weight':8},'qa-'+filename+'-thick');light=convert(src,{'weight':-5},'qa-'+filename+'-thin')
 im0,b0=render(src,'FONT 8:45');imb,bb=render(dark,'FONT 8:45');imt,bt=render(light,'FONT 8:45')
 mass=lambda im:sum(im.histogram()[i]*i for i in range(256))
 check(mass(imb)>mass(im0)*1.03,filename+' actual thicker raster')
 check(mass(imt)<mass(im0)*.98,filename+' actual thinner raster')
 # Glyph contours, including holes, must never be dropped by geometric weight adjustment.
 for p in [dark,light]:
  ff=TTFont(p);fc=ff.getBestCmap()
  for ch in '0869AB':
   g=ff['glyf'][fc[ord(ch)]];check(g.numberOfContours>0,filename+' visible '+ch+' '+p.stem)
 outputs.append({'source':filename,'glyphs':f['maxp'].numGlyphs,'coverage':len(c1),'thinInkRatio':mass(imt)/mass(im0),'boldInkRatio':mass(imb)/mass(im0)})
# Real native-variable weight is frozen, not a fake stroke.
src=OUT/'cffvar.otf';dst=convert(src,{'weight':650},'qa-variable650');f=TTFont(dst)
# Evaluate the original variable charstrings directly, avoiding fontTools'
# per-operand integer-rounding during static CFF serialization.
ref=TTFont(src);ref._qa_glyphset=ref.getGlyphSet(location={'wght':650})
check('fvar' not in f and 'CFF2' not in f,'variable font becomes static TrueType')
for ch in 'FONT 8:45':
 if ch==' ':continue
 a=bound(ref,ref.getBestCmap()[ord(ch)]);b=bound(f,f.getBestCmap()[ord(ch)]);check(all(abs(x-y)<2 for x,y in zip(a,b)),'CFF2 wght source coordinates '+ch)
# Corruption, extreme settings, and known unsupported formats must fail explicitly.
for cfg in [{'width':0},{'height':999},{'weight':99},{'leadingZero':True}]:
 p=subprocess.run(['node',str(ROOT/'tests/export_v4.cjs'),str(OUT/'latin.ttf'),json.dumps(cfg),str(OUT/'should-not-exist.ttf')],capture_output=True,text=True);check(p.returncode!=0,'Invalid input blocked '+str(cfg))
report={'checks':len(checks),'allPassed':all(c['passed']for c in checks),'fonts':outputs,'details':checks,'AndroidDeviceTested':False}
(ROOT/'build/v4_generic_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items()if k!='details'},ensure_ascii=False,indent=2))
