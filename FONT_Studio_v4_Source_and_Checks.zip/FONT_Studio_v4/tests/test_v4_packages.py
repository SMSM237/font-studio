"""fontTools, FreeType, Python cryptography, AXML and ARSC independent checks."""
from pathlib import Path
import sys,io,json,zipfile,xml.etree.ElementTree as ET
from fontTools.ttLib import TTFont
from PIL import Image, ImageDraw, ImageFont,ImageChops
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'build/tests'
sys.path.insert(0,str(ROOT/'src'))
from android_binary import decode_manifest
from test_apk_signature import verify_v2
from v3_package_tools import icon_resource,assert_stored_aligned
NS='{http://schemas.android.com/apk/res/android}'
LABEL='나의 시계 & Edge 01'
def main():
    raster=0;results=[]
    for tag,ext,sample in [('latin','ttf','FONT 08:45'),('hangul','ttf','가나다 월요일 123'),('cff','otf','FONT 08:45'),('cffvar','otf','FONT 08:45')]:
        before=OUT/f'{tag}.{ext}';after=OUT/f'{tag}-renamed.{ext}'
        a,b=TTFont(before),TTFont(after)
        assert a.getBestCmap()==b.getBestCmap() and a.getGlyphOrder()==b.getGlyphOrder()
        for id in (1,4,16,18,21):
            assert b['name'].getName(id,3,1,0x409).toUnicode()==LABEL
            assert b['name'].getName(id,3,1,0x412).toUnicode()==LABEL
        for id in (0,13,14):
            ra=[(n.platformID,n.platEncID,n.langID,n.string)for n in a['name'].names if n.nameID==id]
            rb=[(n.platformID,n.platEncID,n.langID,n.string)for n in b['name'].names if n.nameID==id]
            assert ra==rb,('licence records',tag,id)
        for size in (28,80,160):
            images=[]
            for file in (before,after):
                im=Image.new('L',(2400,400));f=ImageFont.truetype(str(file),size);ImageDraw.Draw(im).text((50,50),sample,font=f,fill=255,anchor='lt');images.append(im)
            assert ImageChops.difference(*images).getbbox()is None,tag
            raster+=1
    for file in ['latin-result.apk','hangul-result.apk','cff-result.apk','cffvar-result.apk','oppo-result.apk','ui-oppo.apk','ui-hangul.apk']:
        path=OUT/file;signature=verify_v2(path);raw=path.read_bytes()
        with zipfile.ZipFile(path)as z:
            doc=decode_manifest(z.read('AndroidManifest.xml'));app=doc.find('application')
            expected='나의 한글 폰트' if file=='ui-hangul.apk'else LABEL
            assert app.get(NS+'label')==expected,(file,app.attrib)
            assert app.get(NS+'hasCode')=='false' and app.get(NS+'icon')==str(0x7f010000)
            assert not doc.findall('uses-permission') and not list(app) and 'classes.dex'not in z.namelist()
            res=icon_resource(z.read('resources.arsc'),doc.get('package'));assert_stored_aligned(z,raw,'resources.arsc')
            assert z.read(res[0x7f010000])==(ROOT/'res/drawable-nodpi/font_logo.png').read_bytes()
            xmlname=next(n for n in z.namelist()if n.startswith('assets/xml/'))
            xml=ET.fromstring(z.read(xmlname));assert xml.get('displayname')==expected
            fn='assets/fonts/'+xml.find('sans/file/filename').text;font=TTFont(io.BytesIO(z.read(fn)))
            assert font['name'].getDebugName(1)==expected and font['name'].getDebugName(4)==expected
            meta=json.loads(z.read('assets/fontstudio-settings.json'));assert meta['name']==expected and meta['package']==doc.get('package')
            results.append({'file':file,'app_and_font_names':expected,'package':doc.get('package'),'icon_resolves':True,'v2_signature_valid':signature['v2_signature_valid'],'source_code_copied':False})
    report={'unchanged_generic_freetype_raster_cases':raster,'checked_generated_packages':results,'AndroidRuntimeTested':False}
    (ROOT/'build/v4_package_names_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
