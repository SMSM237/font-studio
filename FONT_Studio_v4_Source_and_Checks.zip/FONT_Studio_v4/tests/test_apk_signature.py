import struct,hashlib,zipfile,io,json
from pathlib import Path
from cryptography import x509
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import padding
u32=lambda a,p:struct.unpack_from('<I',a,p)[0]
u64=lambda a,p:struct.unpack_from('<Q',a,p)[0]
def length_prefixed(a,p=0):
 n=u32(a,p);assert p+4+n<=len(a);return a[p+4:p+4+n],p+4+n

def verify_v2(path):
 a=Path(path).read_bytes();e=a.rfind(b'PK\x05\x06');assert e>=0 and e+22+struct.unpack_from('<H',a,e+20)[0]==len(a)
 cd=u32(a,e+16);assert a[cd-16:cd]==b'APK Sig Block 42'
 size=u64(a,cd-24);start=cd-size-8;assert u64(a,start)==size
 p=start+8;v2=None
 while p<cd-24:
  n=u64(a,p);tag=u32(a,p+8)
  if tag==0x7109871a:v2=a[p+12:p+8+n]
  p+=8+n
 assert p==cd-24 and v2 is not None
 all_signers,_=length_prefixed(v2);signer,end=length_prefixed(all_signers);assert end==len(all_signers)
 signed_data,p=length_prefixed(signer);sigs,p=length_prefixed(signer,p);spki,p=length_prefixed(signer,p);assert p==len(signer)
 sigrec,_=length_prefixed(sigs);assert u32(sigrec,0)==0x103;signature,_=length_prefixed(sigrec,4)
 digs,p=length_prefixed(signed_data);certs,p=length_prefixed(signed_data,p);attrs,p=length_prefixed(signed_data,p);assert p==len(signed_data)
 certb,_=length_prefixed(certs);cert=x509.load_der_x509_certificate(certb);pub=serialization.load_der_public_key(spki)
 assert pub.public_numbers()==cert.public_key().public_numbers()
 pub.verify(signature,signed_data,padding.PKCS1v15(),hashes.SHA256())
 pub.verify(cert.signature,cert.tbs_certificate_bytes,padding.PKCS1v15(),cert.signature_hash_algorithm)
 dr,_=length_prefixed(digs);assert u32(dr,0)==0x103;expected,_=length_prefixed(dr,4)
 ez=bytearray(a[e:]);struct.pack_into('<I',ez,16,start);hashes_list=[]
 for part in [a[:start],a[cd:e],bytes(ez)]:
  for j in range(0,len(part),1048576):
   c=part[j:j+1048576];hashes_list.append(hashlib.sha256(b'\xa5'+struct.pack('<I',len(c))+c).digest())
 actual=hashlib.sha256(b'\x5a'+struct.pack('<I',len(hashes_list))+b''.join(hashes_list)).digest();assert actual==expected
 with zipfile.ZipFile(io.BytesIO(a))as z:assert z.testzip()is None;files=z.namelist()
 return {'v2_signature_valid':True,'certificate_self_signature_valid':True,'apk_content_digest_valid':True,'zip_crc_valid':True,'entries':files,'sha256':hashlib.sha256(a).hexdigest(),'certificate_sha256':cert.fingerprint(hashes.SHA256()).hex()}
if __name__=='__main__':
 import sys
 print(json.dumps(verify_v2(sys.argv[1]),indent=2))
