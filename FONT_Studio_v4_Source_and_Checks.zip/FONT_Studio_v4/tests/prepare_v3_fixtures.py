"""Local-only fonts for tests; none are copied into deliverables."""
from pathlib import Path
from fontTools.ttLib import TTFont,TTCollection
import zipfile,os,json
root=Path(__file__).resolve().parents[1];out=root/'build/tests';out.mkdir(parents=True,exist_ok=True)
paths={'latin':Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'),'hangul':Path('/usr/share/fonts/truetype/nanum/NanumSquareR.ttf'),'cff':Path('/usr/share/fonts/opentype/artemisia/GFSArtemisia.otf'),'cffvar':Path('/usr/share/fonts/opentype/cantarell/Cantarell-VF.otf')}
for name,p in paths.items():
 if p.exists(): (out/(name+p.suffix)).write_bytes(p.read_bytes())
c=TTCollection();c.fonts=[TTFont(paths['latin']),TTFont(paths['hangul'])];c.save(out/'twofaces.ttc')
c=TTCollection();c.fonts=[TTFont(paths['cff']),TTFont(paths['cffvar'])];c.save(out/'twofaces.otc')
with zipfile.ZipFile(out/'multi.apk','w',zipfile.ZIP_DEFLATED) as z:
 z.write(paths['latin'],'assets/fonts/latin.ttf');z.write(paths['cff'],'assets/fonts/cff.otf');z.writestr('classes.dex',b'DO NOT EXECUTE')
original=Path(os.getenv('OPPO_APK','/mnt/data/OPPOBigClockSansShort.apk'))
with zipfile.ZipFile(original)as z:(out/'oppo.ttf').write_bytes(z.read('assets/fonts/LOCKSCREENOPPOBigClockShort.ttf'))
