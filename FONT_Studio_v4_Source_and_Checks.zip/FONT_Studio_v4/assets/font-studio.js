/* FONT Studio 3. User-input-only packaging. No font, key, or remote code bundled.
 * Generic fonts: real outline editing via GenericEditor; full glyph IDs retained.
 * The separately regression-tested EdgeB engine edits only the known OPPO source.
 */
'use strict';
const FontStudio=(()=>{
 const E=typeof EdgeB!=='undefined'?EdgeB:require('./engine.js');
 const G=()=>typeof GenericEditor!=='undefined'?GenericEditor:require('./generic-editor.js');
 const enc=new TextEncoder(),dec=new TextDecoder(),utf16=new TextDecoder('utf-16be');
 const A=x=>x instanceof Uint8Array?x:new Uint8Array(x),cat=E.cat;
 const u16=(a,p)=>(a[p]<<8)|a[p+1],u32=(a,p)=>((a[p]*16777216)+(a[p+1]<<16)+(a[p+2]<<8)+a[p+3])>>>0;
 const l16=(a,p)=>a[p]|a[p+1]<<8,l32=(a,p)=>(a[p]|a[p+1]<<8|a[p+2]<<16|a[p+3]<<24)>>>0;
 const be16=v=>Uint8Array.of(v>>>8&255,v&255),be32=v=>Uint8Array.of(v>>>24,v>>>16&255,v>>>8&255,v&255);
 const le16=v=>Uint8Array.of(v&255,v>>>8&255),le32=v=>Uint8Array.of(v&255,v>>>8&255,v>>>16&255,v>>>24&255);
 const put16=(a,p,v)=>a.set(be16(v),p),put32=(a,p,v)=>a.set(be32(v),p),pl32=(a,p,v)=>a.set(le32(v),p);
 const need=(c,m)=>{if(!c)throw Error(m)},MAX_FONT=24*1024*1024,MAX_INPUT=64*1024*1024,MAX_TOTAL=48*1024*1024;
 const tag=(a,p)=>String.fromCharCode(...a.subarray(p,p+4));
 function parse(data,offset=0){
  const a=A(data);need(a.length<=MAX_INPUT&&offset>=0&&offset+12<=a.length,'폰트 파일 크기 또는 헤더가 잘못되었습니다.');
  const flavor=u32(a,offset);need([0x10000,0x4f54544f,0x74727565].includes(flavor),'지원 형식: .ttf, .otf, .ttc, .otc, 폰트 포함 .apk. WOFF/WOFF2는 지원하지 않습니다.');
  const n=u16(a,offset+4);need(n>0&&n<=256&&offset+12+n*16<=a.length,'폰트 테이블 목록이 손상되었습니다.');
  const tables=new Map();let total=0;
  for(let i=0;i<n;i++){
   const p=offset+12+16*i,k=tag(a,p),at=u32(a,p+8),len=u32(a,p+12);
   need(/^[\x20-\x7e]{4}$/.test(k)&&!tables.has(k),'폰트 테이블 이름 또는 중복 오류');
   need(at<=a.length&&len<=a.length-at,'폰트 테이블 범위 오류: '+k);
   total+=len;need(total<=MAX_FONT,'글꼴 하나는 24 MB 이하여야 합니다.');tables.set(k,a.slice(at,at+len));
  }
  for(const key of ['head','maxp','cmap','name','hhea','hmtx'])need(tables.has(key),'필수 폰트 테이블 없음: '+key);
  need(tables.get('head').length>=54&&tables.get('maxp').length>=6&&tables.get('hhea').length>=36,'폰트 필수 헤더가 손상되었습니다.');
  need(tables.has('glyf')&&tables.has('loca')||tables.has('CFF ')||tables.has('CFF2'),'지원하는 윤곽선 테이블이 없습니다.');
  const upm=u16(tables.get('head'),18),glyphs=u16(tables.get('maxp'),4);need(upm>=16&&upm<=16384&&glyphs>0,'글꼴 내부 크기/글리프 수 오류');
  return{flavor,tables,upm,glyphs};
 }
 function assemble(t,flavor){
  const tableMap=new Map([...t].map(([k,v])=>[k,v.slice()]));const head=tableMap.get('head');need(head&&head.length>=54,'head 테이블 없음');put32(head,8,0);
  const names=Array.from(tableMap.keys()).sort(),n=names.length,pow=2**Math.floor(Math.log2(n));let pos=12+16*n,total=pos;
  for(const k of names)total+=(tableMap.get(k).length+3)&~3;need(total<=MAX_FONT,'변환한 폰트가 24 MB를 초과합니다.');
  const o=new Uint8Array(total);put32(o,0,flavor===0x74727565?0x10000:flavor);put16(o,4,n);put16(o,6,pow*16);put16(o,8,Math.log2(pow));put16(o,10,n*16-pow*16);let ho=0;
  names.forEach((k,i)=>{const b=tableMap.get(k),p=12+16*i;o.set(enc.encode(k),p);put32(o,p+4,E.checksum(b));put32(o,p+8,pos);put32(o,p+12,b.length);o.set(b,pos);if(k==='head')ho=pos;pos+=(b.length+3)&~3});
  put32(o,ho+8,(0xb1b0afba-E.checksum(o))>>>0);return o;
 }
 function nameRecords(a){
  need(a&&a.length>=6,'name 테이블 오류');const format=u16(a,0),n=u16(a,2),start=u16(a,4);need(format<=1&&6+12*n<=a.length&&start<=a.length,'name 헤더 오류');
  const records=[],languages=[];
  for(let i=0;i<n;i++){const p=6+12*i,plat=u16(a,p),encoding=u16(a,p+2),lang=u16(a,p+4),id=u16(a,p+6),len=u16(a,p+8),off=u16(a,p+10);need(start+off+len<=a.length,'name 문자열 범위 오류');records.push({plat,encoding,lang,id,bytes:a.slice(start+off,start+off+len)})}
  if(format===1){let p=6+12*n;need(p+2<=a.length,'name 언어 정보 오류');const num=u16(a,p);p+=2;need(p+4*num<=a.length,'name 언어 정보 범위 오류');for(let i=0;i<num;i++,p+=4){const len=u16(a,p),off=u16(a,p+2);need(start+off+len<=a.length,'name 언어 문자열 오류');languages.push(a.slice(start+off,start+off+len))}}
  return{format,records,languages};
 }
 function readNames(a){
  const {records}=nameRecords(a),out={},priority={};
  for(const r of records){const unicode=r.plat===0||r.plat===3;const score=unicode?10+(r.lang===0x409?2:0):1;if((priority[r.id]||0)>score)continue;
   try{const s=unicode?utf16.decode(r.bytes):dec.decode(r.bytes);out[r.id]=s;priority[r.id]=score}catch(_){}
  }return out;
 }
 function validateName(value){
  need(typeof value==='string','이름을 입력하세요.');const s=value.normalize('NFC').trim();need(s.length&&Array.from(s).length<=48,'이름은 1~48글자로 입력하세요.');
  need(!/[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069\\/:*?"<>|]/u.test(s)&&s!=='.'&&s!=='..'&&!s.endsWith('.'),'이름에 제어문자나 \\ / : * ? " < > | 문자는 사용할 수 없습니다.');
  need(!/\.(apk|ttf|otf|ttc|otc)$/i.test(s),'확장자는 자동으로 붙습니다. 이름만 입력하세요.');return s;
 }
 function suggestedName(value){let s=String(value||'나의 폰트').normalize('NFC').replace(/[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069\\/:*?"<>|]/gu,' ').replace(/\.(apk|ttf|otf|ttc|otc)$/i,'').trim().replace(/\.+$/,'');return Array.from(s||'나의 폰트').slice(0,48).join('')}
 function utf16be(s){const out=new Uint8Array(s.length*2);for(let i=0;i<s.length;i++)put16(out,i*2,s.charCodeAt(i));return out}
 function renamedNameTable(old,label,postScript){
  const data=nameRecords(old),replace=new Set([1,3,4,6,16,18,20,21,25]);
  const records=data.records.filter(r=>!replace.has(r.id));
  // Copyright/licence/designer, style names, language tags, and variable instance names stay intact.
  const names={1:label,3:'FONTStudio;'+postScript,4:label,6:postScript,16:label,18:label,21:label,25:postScript.replace(/[^a-zA-Z0-9]/g,'')};
  for(const lang of [0x409,0x412])for(const [id,s]of Object.entries(names))records.push({plat:3,encoding:1,lang,id:+id,bytes:utf16be(s)});
  records.push({plat:1,encoding:0,lang:0,id:6,bytes:enc.encode(postScript)});
  records.sort((a,b)=>a.plat-b.plat||a.encoding-b.encoding||a.lang-b.lang||a.id-b.id);
  const extra=data.format===1?2+data.languages.length*4:0,start=6+12*records.length+extra;need(start<65536,'이름 테이블이 너무 큽니다.');
  const unique=new Map(),chunks=[];let cursor=0;function add(b){const k=E.b64(b);if(unique.has(k))return unique.get(k);const at=cursor;unique.set(k,at);chunks.push(b);cursor+=b.length;need(cursor<65536,'이름 문자열이 너무 많습니다.');return at}
  const offsets=records.map(r=>add(r.bytes)),langs=data.languages.map(add),out=new Uint8Array(start+cursor);put16(out,0,data.format);put16(out,2,records.length);put16(out,4,start);
  records.forEach((r,i)=>[r.plat,r.encoding,r.lang,r.id,r.bytes.length,offsets[i]].forEach((v,j)=>put16(out,6+12*i+2*j,v)));
  if(data.format===1){let p=6+12*records.length;put16(out,p,data.languages.length);p+=2;data.languages.forEach((b,i)=>{put16(out,p+4*i,b.length);put16(out,p+4*i+2,langs[i])})}
  out.set(cat(...chunks),start);return out;
 }
 function fontNamed(raw,name,ps){const label=validateName(name);need(/^[A-Za-z0-9-]{1,63}$/.test(ps),'PostScript 식별자 오류');const p=parse(raw);p.tables.set('name',renamedNameTable(p.tables.get('name'),label,ps));p.tables.delete('DSIG');return assemble(p.tables,p.flavor)}
 async function describe(raw,sourceName,index){
  const p=parse(raw),names=readNames(p.tables.get('name')),original=E.hex(await E.digest(raw))===E.EXPECTED;
  return{bytes:raw,sourceName,index,name:names[4]||names[16]||names[1]||sourceName,mode:original?'oppo':'editable',capabilities:original?null:G().inspect(raw),extension:p.tables.has('glyf')?'.ttf':'.otf',variable:p.tables.has('fvar'),glyphs:p.glyphs,upm:p.upm,copyright:names[0]||'',license:names[13]||'',sha256:E.hex(await E.digest(raw))};
 }
 async function faces(a,name){
  if(tag(a,0)!=='ttcf'){parse(a);need(a.length<=MAX_FONT,'폰트는 24 MB 이하여야 합니다.');return[await describe(a.slice(),name,0)]}
  need(a.length>=16,'TTC 헤더가 손상되었습니다.');const n=u32(a,8);need(n>0&&n<=128&&12+4*n<=a.length,'TTC/OTC 글꼴 수 오류');const out=[];let total=0;
  for(let i=0;i<n;i++){const offset=u32(a,12+4*i),p=parse(a,offset),font=assemble(p.tables,p.flavor);total+=font.length;need(total<=MAX_TOTAL,'모음 글꼴의 전체 크기는 48 MB 이하여야 합니다.');out.push(await describe(font,name+' #'+(i+1),i))}return out;
 }
 async function inflateBounded(compressed,expected){
  need(typeof DecompressionStream==='function','압축을 풀 수 없는 WebView입니다. TTF/OTF 파일을 직접 선택하세요.');
  const reader=new Blob([compressed]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader();const chunks=[];let total=0;
  try{while(true){const r=await reader.read();if(r.done)break;total+=r.value.length;if(total>expected||total>MAX_FONT){await reader.cancel();throw Error('APK 압축 해제 크기 제한을 초과했습니다.')}chunks.push(r.value)}}finally{reader.releaseLock()}
  need(total===expected,'APK 압축 해제 크기가 일치하지 않습니다.');return cat(...chunks);
 }
 async function importFiles(raw,filename='font.ttf'){
  const a=A(raw);need(a.length>3&&a.length<=MAX_INPUT,'입력 파일은 64 MB 이하여야 합니다.');
  if(l32(a,0)!==0x04034b50)return faces(a,filename);
  let e=-1;for(let p=a.length-22;p>=Math.max(0,a.length-65557);p--)if(l32(a,p)===0x06054b50&&p+22+l16(a,p+20)===a.length){e=p;break}
  need(e>=0&&l16(a,e+4)===0&&l16(a,e+6)===0,'APK ZIP 구조 오류 또는 분할 압축은 지원하지 않습니다.');const num=l16(a,e+10),start=l32(a,e+16),cdlen=l32(a,e+12);need(num>0&&num<=5000&&start+cdlen<=e,'APK 목록 범위 오류');
  let p=start,total=0;const matches=[],seen=new Set();
  for(let i=0;i<num;i++){
   need(p+46<=e&&l32(a,p)===0x02014b50,'APK 디렉터리 오류');const flags=l16(a,p+8),method=l16(a,p+10),crc=l32(a,p+16),sz=l32(a,p+20),un=l32(a,p+24),nl=l16(a,p+28),el=l16(a,p+30),cl=l16(a,p+32),off=l32(a,p+42);need(p+46+nl+el+cl<=start+cdlen,'APK 파일명 범위 오류');const name=dec.decode(a.subarray(p+46,p+46+nl));p+=46+nl+el+cl;
   if(!/\.(ttf|otf|ttc|otc)$/i.test(name))continue;
   need(!seen.has(name)&&!(flags&1)&&un>0&&un<=MAX_FONT,'중복·암호화된 글꼴 또는 24 MB 초과 글꼴은 지원하지 않습니다.');seen.add(name);total+=un;need(total<=MAX_TOTAL&&matches.length<64,'APK 글꼴 수/전체 크기 제한을 초과합니다.');
   need(off+30<=start&&l32(a,off)===0x04034b50,'APK 내부 파일 헤더 오류');const localNameLen=l16(a,off+26),localExtra=l16(a,off+28),dataStart=off+30+localNameLen+localExtra;
   need(dataStart+sz<=start&&dec.decode(a.subarray(off+30,off+30+localNameLen))===name,'APK 내부 파일 위치 오류');
   const data=a.slice(dataStart,dataStart+sz);let font;if(method===0){need(sz===un,'ZIP 크기 불일치');font=data}else{need(method===8,'지원하지 않는 APK 압축 방식');font=await inflateBounded(data,un)}
   need(E.crc(font)===crc,'APK 안의 폰트 CRC가 일치하지 않습니다.');matches.push(...await faces(font,name));
  }
  need(matches.length,'이 APK 안에는 지원하는 TTF/OTF/TTC/OTC 글꼴이 없습니다.');return matches;
 }
 async function identityForName(raw){const name=validateName(raw),hash=E.hex(await E.digest(enc.encode(name))).slice(0,24);return{name,packageName:'com.monotype.android.font.fontstudio4'+hash,postScriptName:'FONTStudio-'+hash,fileName:name+'.apk',fontFileStem:'FONT'+hash}}
 function nextVersion(pkg){const key='fontstudio-v3-version:'+pkg;let old;try{old=Number(localStorage.getItem(key)||0);need(Number.isSafeInteger(old)&&old>=0&&old<2147483646,'APK 버전 값 오류');localStorage.setItem(key,String(old+1));need(localStorage.getItem(key)===String(old+1),'버전 저장 실패')}catch(e){throw Error('업데이트 버전을 저장하지 못했습니다. '+e.message)}return old+1}
 const NONE=0xffffffff,ANDROID='http://schemas.android.com/apk/res/android';
 const ATTR={label:0x01010001,icon:0x01010002,name:0x01010003,hasCode:0x0101000c,debuggable:0x0101000f,minSdkVersion:0x0101020c,versionCode:0x0101021b,versionName:0x0101021c,targetSdkVersion:0x01010270,allowBackup:0x01010280};
 const chunk=(type,payload,hs=8)=>cat(le16(type),le16(hs),le32(payload.length+8),payload);
 function stringPool(strings){const blobs=[],offs=[];let at=0;for(const s of strings){const b=new Uint8Array(s.length*2);for(let i=0;i<s.length;i++)b.set(le16(s.charCodeAt(i)),2*i);const blob=cat(le16(s.length),b,le16(0));offs.push(at);blobs.push(blob);at+=blob.length}const raw=cat(...blobs),padding=new Uint8Array((4-raw.length%4)%4);return chunk(1,cat(le32(strings.length),le32(0),le32(0),le32(28+strings.length*4),le32(0),...offs.map(le32),raw,padding),28)}
 function fontManifest(pkg,label,version){
  const tree=['manifest',[['package',pkg],['versionCode',version],['versionName','4.0']],[[ 'uses-sdk',[['minSdkVersion',26],['targetSdkVersion',28]],[]],['application',[['label',label],['icon',{resource:0x7f010000}],['hasCode',false],['debuggable',false],['allowBackup',false]],[]]]];
  const strings=['android',ANDROID],add=s=>{if(!strings.includes(s))strings.push(s)},visit=n=>{add(n[0]);for(const[k,v]of n[1]){add(k);if(typeof v==='string')add(v)}n[2].forEach(visit)};visit(tree);const idx=s=>strings.indexOf(s);
  const node=(type,data)=>chunk(type,cat(le32(1),le32(NONE),data),16);
  const emit=n=>{const attrs=n[1].slice().sort((a,b)=>(ATTR[a[0]]||NONE)-(ATTR[b[0]]||NONE));const ab=attrs.map(([k,v])=>{let type,value,raw=NONE;if(typeof v==='boolean'){type=0x12;value=v?NONE:0}else if(typeof v==='number'){type=0x10;value=v}else if(typeof v==='object'){type=1;value=v.resource}else{type=3;value=idx(v);raw=value}return cat(le32(k==='package'?NONE:idx(ANDROID)),le32(idx(k)),le32(raw),le16(8),Uint8Array.of(0,type),le32(value))});return cat(node(0x102,cat(le32(NONE),le32(idx(n[0])),le16(20),le16(20),le16(attrs.length),le16(0),le16(0),le16(0),...ab)),...n[2].map(emit),node(0x103,cat(le32(NONE),le32(idx(n[0])))));};
  const namespace=cat(le32(idx('android')),le32(idx(ANDROID)));
  const resourceMap=chunk(0x180,cat(...strings.map(s=>le32(ATTR[s]||0))));
  const body=cat(stringPool(strings),resourceMap,node(0x100,namespace),emit(tree),node(0x101,namespace));
  return chunk(3,body);
 }
 function resourcesArsc(pkg){
  need(pkg.length<128,'리소스 패키지명 길이 오류');const global=stringPool(['res/drawable-nodpi/font_logo.png']),types=stringPool(['drawable']),keys=stringPool(['font_logo']);
  const header=new Uint8Array(280);pl32(header,0,0x7f);for(let i=0;i<pkg.length;i++)header.set(le16(pkg.charCodeAt(i)),4+2*i);pl32(header,260,288);pl32(header,264,1);pl32(header,268,288+types.length);pl32(header,272,1);pl32(header,276,0);
  const spec=chunk(0x202,cat(Uint8Array.of(1,0,0,0),le32(1),le32(0)),16);
  const config=new Uint8Array(64);pl32(config,0,64); // default config, no density scaling (nodpi value below)
  config.set(le16(0xffff),14); // ResTable_config.density = DENSITY_NONE
  const entry=cat(le16(8),le16(0),le32(0),le16(8),Uint8Array.of(0,3),le32(0));
  const type=chunk(0x201,cat(Uint8Array.of(1,0,0,0),le32(1),le32(88),config,le32(0),entry),84);
  const pack=chunk(0x200,cat(header,types,keys,spec,type),288);return chunk(2,cat(le32(1),global,pack),12);
 }
 const escapeXML=s=>s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
 function packageEntries(font,config){
  const name=validateName(config.name),id=config.identity;need(id&&id.name===name,'이름 변경 후 미리보기를 갱신하세요.');need(Number.isInteger(config.version)&&config.version>0&&config.version<2147483647,'APK 버전 오류');
  const p=parse(font),ext=p.tables.has('glyf')?'.ttf':'.otf',fontName=id.fontFileStem+ext;const names=readNames(p.tables.get('name'));need([1,4,16].every(i=>names[i]===name),'폰트 내부 이름이 설치 이름과 일치하지 않습니다.');
  const xml=`<?xml version="1.0" encoding="utf-8"?><font displayname="${escapeXML(name)}"><sans><file><filename>${fontName}</filename><droidname>DroidSans.ttf</droidname></file></sans></font>`;
  need(config.logo&&A(config.logo).length>8,'앱 아이콘 데이터가 없습니다.');
  return[['AndroidManifest.xml',fontManifest(id.packageName,name,config.version)],['resources.arsc',resourcesArsc(id.packageName)],['res/drawable-nodpi/font_logo.png',A(config.logo)],['assets/fonts/'+fontName,font],['assets/xml/'+id.fontFileStem+'.xml',enc.encode(xml)],['assets/fontstudio-settings.json',enc.encode(JSON.stringify({builder:'4.0',name,package:id.packageName,version:config.version,mode:config.mode||'original',source:config.source||null,settings:config.settings||null},null,2))]];
 }
 function missingCharacters(raw,text){
  const c=parse(raw).tables.get('cmap'),ng=parse(raw).glyphs;need(c.length>=4,'cmap 오류');const n=u16(c,2);need(4+8*n<=c.length,'cmap 목록 오류');let formats=[];
  for(let i=0;i<n;i++){const p=4+8*i,plat=u16(c,p),encid=u16(c,p+2),off=u32(c,p+4);if(!(plat===0||plat===3&&[1,10].includes(encid))||off+2>c.length)continue;const f=u16(c,off);if([4,12].includes(f))formats.push([f,off])}
  function has(cp){for(const[f,o]of formats){if(f===12){if(o+16>c.length)continue;const n=u32(c,o+12);if(o+16+n*12>c.length)continue;for(let i=0;i<n;i++){const p=o+16+12*i,a=u32(c,p),b=u32(c,p+4);if(cp>=a&&cp<=b){const gid=u32(c,p+8)+cp-a;return gid>0&&gid<ng}if(cp<a)break}}
   else if(cp<=65535){if(o+14>c.length)continue;const seg=u16(c,o+6)/2,end=o+14,start=end+2*seg+2,delta=start+2*seg,range=delta+2*seg;if(range+2*seg>c.length)continue;for(let i=0;i<seg;i++){const e=u16(c,end+2*i),s=u16(c,start+2*i);if(cp>=s&&cp<=e){const r=u16(c,range+2*i),d=u16(c,delta+2*i);let gid;if(!r)gid=(cp+d)&65535;else{const p=range+2*i+r+2*(cp-s);if(p+2>c.length)return false;gid=u16(c,p);if(gid)gid=(gid+d)&65535}return gid>0&&gid<ng}if(cp<e)break}}
  }return false}return[...new Set(Array.from(text).filter(ch=>!(/\s/u.test(ch))&&!has(ch.codePointAt(0))))];
 }
 return{editFont:(raw,settings,hooks)=>G().edit(raw,settings,hooks),editOptions:(raw,settings)=>G().options(raw,settings),capabilities:raw=>G().inspect(raw),parse,assemble,readNames,validateName,suggestedName,fontNamed,importFiles,identityForName,nextVersion,fontManifest,resourcesArsc,packageEntries,missingCharacters,MAX_FONT,MAX_INPUT};
})();
if(typeof module!=='undefined')module.exports=FontStudio;
