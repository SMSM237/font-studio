/* EdgeTall Studio 2: offline, input-only variable font conversion. No font data is bundled. */
'use strict';
const EdgeB=(()=>{
 const enc=new TextEncoder(), FPATH='assets/fonts/LOCKSCREENOPPOBigClockShort.ttf';
 const EXPECTED='84085b89985255a6cf270240ec4b278ad8c0e259609f9e06d8e4d03c66476cb1';
 const U8=x=>x instanceof Uint8Array?x:new Uint8Array(x), cat=(...a)=>{let n=a.reduce((s,b)=>s+b.length,0),o=new Uint8Array(n),p=0;for(let b of a){o.set(b,p);p+=b.length}return o};
 const u16=(a,p)=>(a[p]<<8)|a[p+1],i16=(a,p)=>(u16(a,p)<<16)>>16,u32=(a,p)=>((a[p]*0x1000000)+(a[p+1]<<16)+(a[p+2]<<8)+a[p+3])>>>0;
 const le16=(a,p)=>a[p]|a[p+1]<<8,le32=(a,p)=>(a[p]|a[p+1]<<8|a[p+2]<<16|a[p+3]<<24)>>>0;
 function put16(a,p,v){a[p]=(v>>>8)&255;a[p+1]=v&255}function put32(a,p,v){a[p]=v>>>24;a[p+1]=(v>>>16)&255;a[p+2]=(v>>>8)&255;a[p+3]=v&255}
 function L16(v){return Uint8Array.of(v&255,v>>>8&255)}function L32(v){return Uint8Array.of(v&255,v>>>8&255,v>>>16&255,v>>>24&255)}
 const lp=a=>cat(L32(a.length),a), L64=v=>cat(L32(v),L32(Math.floor(v/4294967296)));
 function need(c,m){if(!c)throw new Error(m)}
 const hex=a=>Array.from(a,x=>x.toString(16).padStart(2,'0')).join('');
 const b64=a=>{let s='';for(let p=0;p<a.length;p+=8192)s+=String.fromCharCode(...a.subarray(p,p+8192));return btoa(s)};
 const unb64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
 const digest=async a=>new Uint8Array(await crypto.subtle.digest('SHA-256',a));
 const round=v=>Math.floor(v+0.5);
 function checksum(a){let s=0;for(let p=0;p<a.length;p+=4)s=(s+(((a[p]||0)*16777216)+((a[p+1]||0)<<16)+((a[p+2]||0)<<8)+(a[p+3]||0)))>>>0;return s}
 function tables(a){need(a.length>=12&&u32(a,0)===0x10000,'지원하지 않는 폰트 형식입니다.');let n=u16(a,4),m=new Map();need(n>0&&n<100&&12+16*n<=a.length,'폰트 디렉터리가 손상되었습니다.');for(let k=0;k<n;k++){let p=12+k*16,t=String.fromCharCode(...a.subarray(p,p+4)),o=u32(a,p+8),l=u32(a,p+12);need(o+l<=a.length,'폰트 테이블 범위 오류');m.set(t,a.slice(o,o+l))}return m}
 function readGlyph(a,off,end){if(off===end)return{ep:[],f:[],x:[],y:[],xmin:0};need(end<=a.length&&off+10<=end,'글리프 범위 오류');let n=i16(a,off);need(n>=0,'복합 글리프는 이 변환기의 대상이 아닙니다.');let p=off+10,ep=[];for(let j=0;j<n;j++,p+=2)ep.push(u16(a,p));let count=n?ep[n-1]+1:0;need(count<4096,'글리프 점 수 제한');let il=u16(a,p);p+=2+il;let f=[];while(f.length<count){let flag=a[p++];f.push(flag);if(flag&8){let rep=a[p++];while(rep-->0)f.push(flag)}}need(f.length===count,'글리프 플래그 오류');let x=[],y=[],v=0;for(let flag of f){let d=0;if(flag&2){d=a[p++];if(!(flag&16))d=-d}else if(!(flag&16)){d=i16(a,p);p+=2}x.push(v+=d)}v=0;for(let flag of f){let d=0;if(flag&4){d=a[p++];if(!(flag&32))d=-d}else if(!(flag&32)){d=i16(a,p);p+=2}y.push(v+=d)}need(p<=end,'글리프 좌표 범위 오류');return{ep,f:f.map(x=>x&1),x,y,xmin:i16(a,off+2)}}
 function points(a,o,total){let p=o,c=a[p++];if(c&128)c=((c&127)<<8)|a[p++];if(c===0)return{v:Array.from({length:total},(_,i)=>i),p};let v=[],last=0;while(v.length<c){let flag=a[p++],n=(flag&127)+1;for(let j=0;j<n;j++){let d;if(flag&128){d=u16(a,p);p+=2}else d=a[p++];v.push(last+=d)}}need(v.length===c&&last<total,'변형 점 목록 오류');return{v,p}}
 function deltas(a,o,count){let p=o,v=[];while(v.length<count){let flag=a[p++],n=(flag&63)+1;for(let j=0;j<n;j++){let d=0;if(!(flag&128)){if(flag&64){d=i16(a,p);p+=2}else {d=(a[p++]<<24)>>24}}v.push(d)}}need(v.length===count,'변형 값 목록 오류');return{v,p}}
 function infer(c,d,ep){let out=d.slice(),start=0;for(let end of ep){let refs=[];for(let i=start;i<=end;i++)if(d[i]!==null)refs.push(i);if(!refs.length){for(let i=start;i<=end;i++)out[i]=0}else for(let i=start;i<=end;i++)if(out[i]===null){let prev=refs[refs.length-1],next=refs[0];for(let r of refs){if(r<i)prev=r;if(r>i){next=r;break}}let a=c[prev],b=c[next],da=d[prev],db=d[next];if(a===b)out[i]=da===db?da:0;else{if(a>b){[a,b]=[b,a];[da,db]=[db,da]}out[i]=c[i]<=a?da:c[i]>=b?db:da+(db-da)*(c[i]-a)/(b-a)}}start=end+1}return out.map(v=>v===null?0:v)}
 function variations(gv,gid,g,norm,aw,lsb){let axes=u16(gv,4),sharedCount=u16(gv,6),sharedAt=u32(gv,8),flags=u16(gv,14),dataAt=u32(gv,16),long=flags&1;let off=i=>long?u32(gv,20+i*4):u16(gv,20+i*2)*2;let begin=dataAt+off(gid),end=dataAt+off(gid+1);let x=g.x.concat([g.xmin-lsb,g.xmin-lsb+aw,0,0]),y=g.y.concat([0,0,0,0]),dx=Array(x.length).fill(0),dy=dx.slice();if(begin===end)return{x,y};need(end<=gv.length,'gvar 범위 오류');let count=u16(gv,begin),serial=begin+u16(gv,begin+2),p=begin+4,items=[];for(let j=0;j<(count&4095);j++){let size=u16(gv,p),tag=u16(gv,p+2);p+=4;let peak=[],start=[],stop=[];if(tag&0x8000){for(let a=0;a<axes;a++,p+=2)peak.push(i16(gv,p)/16384)}else{let idx=tag&4095;need(idx<sharedCount,'변형 튜플 오류');for(let a=0;a<axes;a++)peak.push(i16(gv,sharedAt+(idx*axes+a)*2)/16384)}if(tag&0x4000){for(let a=0;a<axes;a++,p+=2)start.push(i16(gv,p)/16384);for(let a=0;a<axes;a++,p+=2)stop.push(i16(gv,p)/16384)}else{start=peak.map(v=>Math.min(v,0));stop=peak.map(v=>Math.max(v,0))}let scale=1;for(let a=0;a<axes;a++){let [s,k,e,v]=[start[a],peak[a],stop[a],norm[a]];if(k===0)continue;if(s>k||k>e||s<0&&e>0)continue;if(v===k)continue;if(v<=s||v>=e){scale=0;break}scale*=v<k?(v-s)/(k-s):(v-e)/(k-e)}items.push({size,tag,scale})}need(p<=serial,'튜플 헤더 오류');let shared=Array.from({length:x.length},(_,i)=>i);if(count&0x8000){let r=points(gv,serial,x.length);shared=r.v;serial=r.p}for(let item of items){let finish=serial+item.size;need(finish<=end,'튜플 데이터 범위 오류');if(item.scale){let pos=serial,ps=shared;if(item.tag&0x2000){let r=points(gv,pos,x.length);pos=r.p;ps=r.v}let vx=deltas(gv,pos,ps.length),vy=deltas(gv,vx.p,ps.length);need(vy.p<=finish,'튜플 델타 범위 오류');let tx=Array(x.length).fill(null),ty=tx.slice();ps.forEach((id,i)=>{tx[id]=vx.v[i];ty[id]=vy.v[i]});tx=infer(x,tx,g.ep);ty=infer(y,ty,g.ep);for(let i=0;i<x.length;i++){dx[i]+=tx[i]*item.scale;dy[i]+=ty[i]*item.scale}}serial=finish}return{x:x.map((v,i)=>v+dx[i]),y:y.map((v,i)=>v+dy[i])}}
 function encodeGlyph(g){let n=g.x.length;if(!n)return new Uint8Array(0);let size=12+2*g.ep.length+5*n,out=new Uint8Array(size+(size%2)),p=10;put16(out,0,g.ep.length);let box=[Math.min(...g.x),Math.min(...g.y),Math.max(...g.x),Math.max(...g.y)];box.forEach((v,i)=>put16(out,2+2*i,v));for(let e of g.ep){put16(out,p,e);p+=2}put16(out,p,0);p+=2;g.f.forEach((f,i)=>{out[p++]=f|(i===0?64:0)});let prev=0;for(let v of g.x){put16(out,p,v-prev);prev=v;p+=2}prev=0;for(let v of g.y){put16(out,p,v-prev);prev=v;p+=2}return out}
 function rename(old,options){let n=u16(old,2),s=u16(old,4),records=[];for(let i=0;i<n;i++){let p=6+i*12,plat=u16(old,p),encoding=u16(old,p+2),lang=u16(old,p+4),id=u16(old,p+6),l=u16(old,p+8),o=u16(old,p+10);if(![1,2,3,4,6,16,17,25].includes(id)&&id<256)records.push({plat,encoding,lang,id,v:old.slice(s+o,s+o+l)})}let id='W'+options.width+'H'+options.height+'T'+options.weight+'S'+options.spacing+'Z'+Number(options.leadingZero);let names={1:'EdgeTall Studio '+id,2:'Regular',3:'EdgeTall-Studio-2-'+id,4:'EdgeTall Studio '+id,6:'EdgeTallStudio-'+id.replace(/[^A-Za-z0-9]/g,''),16:'EdgeTall Studio '+id,17:'Regular'};for(let [id,t]of Object.entries(names)){let b=new Uint8Array(t.length*2);for(let i=0;i<t.length;i++)put16(b,2*i,t.charCodeAt(i));records.push({plat:3,encoding:1,lang:0x409,id:+id,v:b})}records.sort((a,b)=>a.plat-b.plat||a.encoding-b.encoding||a.lang-b.lang||a.id-b.id);let start=6+12*records.length,o=new Uint8Array(start+records.reduce((s,r)=>s+r.v.length,0)),cur=start;put16(o,2,records.length);put16(o,4,start);records.forEach((r,i)=>{[r.plat,r.encoding,r.lang,r.id,r.v.length,cur-start].forEach((v,j)=>put16(o,6+12*i+2*j,v));o.set(r.v,cur);cur+=r.v.length});return o}
 function assemble(t){let names=Array.from(t.keys()).sort(),n=names.length,off=12+16*n,total=off;for(let tag of names)total+=(t.get(tag).length+3)&~3;let o=new Uint8Array(total),search=2**Math.floor(Math.log2(n));put32(o,0,0x10000);put16(o,4,n);put16(o,6,search*16);put16(o,8,Math.log2(search));put16(o,10,n*16-search*16);let ho=0;names.forEach((tag,i)=>{let b=t.get(tag),p=12+i*16;o.set(enc.encode(tag),p);put32(o,p+4,checksum(b));put32(o,p+8,off);put32(o,p+12,b.length);o.set(b,off);if(tag==='head')ho=off;off+=(b.length+3)&~3});put32(o,ho+8,(0xb1b0afba-checksum(o))>>>0);return o}

 // Public controls are percentages (width/height), a true wght axis, and tracking in % em.
 const DEFAULTS=Object.freeze({width:100,height:100,weight:500,spacing:0,leadingZero:false});
 function optionsFor(input={}){
   need(input&&typeof input==='object'&&!Array.isArray(input),'조절값 형식이 잘못되었습니다.');
   const o={...DEFAULTS,...input};
   const ranges={width:[50,150],height:[60,140],weight:[0,1000],spacing:[-10,20]};
   for(const [name,[lo,hi]] of Object.entries(ranges))
     need(typeof o[name]==='number'&&Number.isFinite(o[name])&&Number.isInteger(o[name])&&o[name]>=lo&&o[name]<=hi,'조절값 범위 오류: '+name);
   need(typeof o.leadingZero==='boolean','앞자리 0 옵션은 켜기/끄기로 지정하세요.');
   return o;
 }
 const B16=(...values)=>{const a=new Uint8Array(values.length*2);values.forEach((v,i)=>put16(a,2*i,v));return a};
 function coverage(ids){return B16(1,ids.length,...ids)}
 function contextRule(back,input,ahead,pad){
   const words=[3,back.length],refs=[];
   function offsets(sets){for(const set of sets){refs.push([words.length,set]);words.push(0)}}
   offsets(back);words.push(input.length);offsets(input);words.push(ahead.length);offsets(ahead);
   words.push(pad?1:0);if(pad)words.push(0,1); // input[0] -> nested MultipleSubst lookup 1
   let pos=words.length*2,rest=[];
   for(const [slot,set] of refs){words[slot]=pos;let c=coverage(set);rest.push(c);pos+=c.length}
   return cat(B16(...words),...rest);
 }
 function lookup(type,subtables){
   let offset=6+2*subtables.length,offsets=[];
   for(const sub of subtables){offsets.push(offset);offset+=sub.length}
   return cat(B16(type,0,subtables.length,...offsets),...subtables);
 }
 function leadingZeroGSUB(){
   // The inspected source has GIDs 2..11 for 0..9 and GID 12 for colon.
   // Ignore a digit preceded by another digit or a colon: never pad minutes/seconds
   // or the units position of an already two-digit hour.
   const digits=Array.from({length:10},(_,i)=>i+2), colon=[12];
   const outer=lookup(6,[contextRule([digits],[digits],[colon],false),
                         contextRule([colon],[digits],[colon],false),
                         contextRule([],[digits],[colon,digits.slice(0,6),digits],true)]);
   const sequences=digits.map(id=>B16(2,2,id));
   let start=6+2*digits.length,offs=[];
   for(const seq of sequences){offs.push(start);start+=seq.length}
   const multiple=cat(B16(1,start,digits.length,...offs),...sequences,coverage(digits));
   const inner=lookup(2,[multiple]);
   const lookups=cat(B16(2,6,6+outer.length),outer,inner);
   // rlig is a required feature; actual adoption by a Samsung clock remains device-dependent.
   const script=cat(B16(4,0),B16(0,0,0));
   const scripts=cat(B16(2),enc.encode('DFLT'),B16(14),enc.encode('latn'),B16(14+script.length),script,script);
   const features=cat(B16(1),enc.encode('rlig'),B16(8),B16(0,1,0));
   return cat(B16(1,0,10,10+scripts.length,10+scripts.length+features.length),scripts,features,lookups);
 }
 function instantiate(input,settings={}){
   const options=optionsFor(settings),sx=options.width/100,sy=options.height/100;
   let t=tables(U8(input));
   for(let r of ['head','hhea','hmtx','loca','glyf','maxp','cmap','name','fvar','gvar'])need(t.has(r),'필수 테이블 없음: '+r);
   for(let r of ['HVAR','VVAR','MVAR','avar','CFF2','cvar'])need(!t.has(r),'이 원본에 없는 변형 형식: '+r);
   let fv=t.get('fvar'),count=u16(fv,8),asz=u16(fv,10),aoff=u16(fv,4),norm=[];
   need(count===2,'높이/굵기 2축 폰트만 지원합니다.');
   for(let i=0;i<count;i++){
     let p=aoff+i*asz,tag=String.fromCharCode(...fv.subarray(p,p+4)),
         lo=(u32(fv,p+4)|0)/65536,def=(u32(fv,p+8)|0)/65536,hi=(u32(fv,p+12)|0)/65536,
         value=tag==='HGHT'?900:tag==='wght'?options.weight:NaN;
     need(Number.isFinite(value)&&value>=lo&&value<=hi,'원본 축 정보가 다릅니다.');
     const normalized=value===def?0:value<def?(value-def)/(def-lo):(value-def)/(hi-def);
     norm.push(round(normalized*16384)/16384); // OpenType F2DOT14 normalization
   }
   let head=t.get('head'),hhea=t.get('hhea'),hm=t.get('hmtx'),lo=t.get('loca'),gf=t.get('glyf'),
       ng=u16(t.get('maxp'),4),nh=u16(hhea,34),short=i16(head,50)===0;
   const tracking=options.spacing*u16(head,18)/100;
   need(ng===13,'검사한 원본과 글리프 수가 다릅니다.');
   let off=i=>short?u16(lo,i*2)*2:u32(lo,i*4),outs=[],loc=[0],metrics=[],allbox=[];
   for(let i=0;i<ng;i++){
     let aw=u16(hm,Math.min(i,nh-1)*4),lsb=i<nh?i16(hm,i*4+2):i16(hm,4*nh+(i-nh)*2),
         g=readGlyph(gf,off(i),off(i+1)),v=variations(t.get('gvar'),i,g,norm,aw,lsb),n=g.x.length;
     g.x=v.x.slice(0,n).map(round);g.y=v.y.slice(0,n).map(round);
     let xmin=n?Math.min(...g.x):0;
     const naturalAdvance=Math.max(0,round(v.x[n+1]-v.x[n])),naturalLSB=round(xmin-v.x[n]),track=i>=2?tracking:0;
     // Match a normal static instance first; then scale outlines and both side bearings.
     g.x=g.x.map(x=>round(x*options.width/100+track/2));g.y=g.y.map(y=>round(y*options.height/100));
     let box=n?[Math.min(...g.x),Math.min(...g.y),Math.max(...g.x),Math.max(...g.y)]:[0,0,0,0];
     need(box.every(v=>v>=-32768&&v<=32767),'글리프 좌표 범위를 벗어났습니다.');
     metrics.push([round(naturalAdvance*options.width/100+track),round(naturalLSB*options.width/100+track/2)]);
     need(metrics[i][0]>=0&&metrics[i][0]<=65535,'글자 배치 폭 오류');
     if(n)allbox.push(box);
     let out=encodeGlyph(g);outs.push(out);loc.push(loc[loc.length-1]+out.length);
   }
   let nlo=new Uint8Array((ng+1)*4),nhm=new Uint8Array(ng*4);
   loc.forEach((v,i)=>put32(nlo,i*4,v));metrics.forEach((v,i)=>{put16(nhm,4*i,v[0]);put16(nhm,4*i+2,v[1])});
   t.set('glyf',cat(...outs));t.set('loca',nlo);t.set('hmtx',nhm);put16(head,50,1);put32(head,8,0);
   [Math.min(...allbox.map(b=>b[0])),Math.min(...allbox.map(b=>b[1])),Math.max(...allbox.map(b=>b[2])),Math.max(...allbox.map(b=>b[3]))].forEach((v,i)=>put16(head,36+i*2,v));
   put16(hhea,34,ng);put16(hhea,10,Math.max(...metrics.map(v=>v[0])));
   let boxes=outs.map(o=>o.length?[i16(o,2),i16(o,6)]:[0,0]);
   put16(hhea,12,Math.min(...metrics.map(v=>v[1])));
   put16(hhea,14,Math.min(...metrics.map((v,i)=>v[0]-v[1]-(boxes[i][1]-boxes[i][0]))));
   put16(hhea,16,Math.max(...metrics.map((v,i)=>v[1]+boxes[i][1]-boxes[i][0])));
   for(const p of [4,6,8])put16(hhea,p,round(i16(hhea,p)*sy));
   if(t.has('OS/2')){
     let os=t.get('OS/2');put16(os,4,Math.max(1,options.weight));
     const nonzero=metrics.filter(v=>v[0]>0);put16(os,2,round(nonzero.reduce((s,v)=>s+v[0],0)/nonzero.length));
     for(const p of [68,70,72])put16(os,p,round(i16(os,p)*sy));
     for(const p of [74,76])put16(os,p,round(u16(os,p)*sy));
     if(os.length>=96)put16(os,94,options.leadingZero?5:0);
   }
   t.set('name',rename(t.get('name'),options));
   for(let tag of ['fvar','gvar','STAT','DSIG','GSUB'])t.delete(tag);
   if(options.leadingZero)t.set('GSUB',leadingZeroGSUB());
   return assemble(t);
 }
 async function extract(source){let a=U8(source);need(a.length<=2097152,'2 MB 이하의 원본 파일만 선택해 주세요.');let font;if(u32(a,0)===0x10000)font=a;else{need(le32(a,0)===0x04034b50,'APK 또는 원본 TTF를 선택해 주세요.');let e=-1;for(let p=a.length-22;p>=Math.max(0,a.length-65557);p--)if(le32(a,p)===0x06054b50&&p+22+le16(a,p+20)===a.length){e=p;break}need(e>=0,'APK ZIP 구조 오류');let num=le16(a,e+10),p=le32(a,e+16),found=false;need(num<1000,'APK 항목 수 제한');for(let i=0;i<num;i++){need(le32(a,p)===0x02014b50,'ZIP 디렉터리 오류');let method=le16(a,p+10),sz=le32(a,p+20),un=le32(a,p+24),nl=le16(a,p+28),el=le16(a,p+30),cl=le16(a,p+32),o=le32(a,p+42),name=new TextDecoder().decode(a.subarray(p+46,p+46+nl));if(name===FPATH){need(!found&&un===9252,'원본 폰트 크기/중복 오류');found=true;need(le32(a,o)===0x04034b50,'ZIP 항목 오류');let st=o+30+le16(a,o+26)+le16(a,o+28),compressed=a.slice(st,st+sz);if(method===0)font=compressed;else{need(method===8,'지원하지 않는 ZIP 압축');let stream=new Blob([compressed]).stream().pipeThrough(new DecompressionStream('deflate-raw'));font=new Uint8Array(await new Response(stream).arrayBuffer())}need(font.length===un&&crc(font)===le32(a,p+16),'폰트 CRC 오류')}p+=46+nl+el+cl}need(font,'선택한 APK에서 검사한 원본 폰트를 찾지 못했습니다.')}need(hex(await digest(font))===EXPECTED,'검사한 원본 폰트와 다릅니다. 변환하지 않았습니다.');return font}
 const crcTable=Array.from({length:256},(_,c)=>{for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;return c>>>0});
 function crc(a){let c=0xffffffff;for(let b of a)c=crcTable[(c^b)&255]^(c>>>8);return (c^0xffffffff)>>>0}
 function zip(entries){
   let locals=[],central=[],o=0;
   for(let [name,data]of entries){
     let n=enc.encode(name),c=crc(data),pad=(4-((o+30+n.length+4)%4))%4,
         extra=cat(L16(0xd935),L16(pad),new Uint8Array(pad)),
         header=cat(L32(0x04034b50),L16(20),L16(0x800),L16(0),L16(0),L16(0x5d2d),L32(c),L32(data.length),L32(data.length),L16(n.length),L16(extra.length),n,extra);
     locals.push(header,data);
     central.push(cat(L32(0x02014b50),L16(20),L16(20),L16(0x800),L16(0),L16(0),L16(0x5d2d),L32(c),L32(data.length),L32(data.length),L16(n.length),L16(0),L16(0),L16(0),L16(0),L32(0),L32(o),n));
     o+=header.length+data.length;
   }
   let cd=cat(...central),e=cat(L32(0x06054b50),L16(0),L16(0),L16(entries.length),L16(entries.length),L32(cd.length),L32(o),L16(0));
   return{local:cat(...locals),cd,e};
 }
 const der=(tag,a)=>{let l=a.length,v=[];if(l<128)v=[l];else{while(l){v.unshift(l&255);l>>>=8}v.unshift(128|v.length)}return cat(Uint8Array.of(tag,...v),a)},seq=(...a)=>der(0x30,cat(...a)),set=(...a)=>der(0x31,cat(...a));
 const oid=s=>{let x=s.split('.').map(Number),v=[x[0]*40+x[1]];for(let n of x.slice(2)){let tmp=[n&127];while(n>>>=7)tmp.unshift((n&127)|128);v.push(...tmp)}return der(6,Uint8Array.from(v))};
 const integer=a=>{while(a.length>1&&a[0]===0)a=a.slice(1);return der(2,a[0]&128?cat(Uint8Array.of(0),a):a)};
 const rsaAlg=()=>seq(oid('1.2.840.113549.1.1.11'),Uint8Array.of(5,0));

 async function identity(){
   const storeKey='fontstudio-v3-signing-v1';let serialized;
   try{serialized=localStorage.getItem(storeKey)}catch(_){throw Error('서명키 저장소를 사용할 수 없습니다. APK를 만들지 않았습니다.')}
   if(serialized!==null){
     try{
       const saved=JSON.parse(serialized);
       const privateKey=await crypto.subtle.importKey('pkcs8',unb64(saved.privateKey),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['sign']);
       const publicKey=await crypto.subtle.importKey('spki',unb64(saved.spki),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);
       return {keys:{privateKey,publicKey},spki:unb64(saved.spki),cert:unb64(saved.cert)};
     }catch(_){throw Error('기존 서명키를 읽지 못했습니다. 다른 키로 덮어쓰지 않았습니다.')}
   }
   const keys=await crypto.subtle.generateKey({name:'RSASSA-PKCS1-v1_5',modulusLength:2048,publicExponent:Uint8Array.of(1,0,1),hash:'SHA-256'},true,['sign','verify']);
   const spki=new Uint8Array(await crypto.subtle.exportKey('spki',keys.publicKey));
   const name=seq(set(seq(oid('2.5.4.3'),der(12,enc.encode('FONT Studio local')))));
   const serial=crypto.getRandomValues(new Uint8Array(16));serial[0]&=127;
   const tbs=seq(der(0xa0,integer(Uint8Array.of(2))),integer(serial),rsaAlg(),name,seq(der(0x17,enc.encode('200101000000Z')),der(0x17,enc.encode('450101000000Z'))),name,spki);
   const sig=new Uint8Array(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',keys.privateKey,tbs));
   const cert=seq(tbs,rsaAlg(),der(3,cat(Uint8Array.of(0),sig)));
   const encoded=JSON.stringify({privateKey:b64(new Uint8Array(await crypto.subtle.exportKey('pkcs8',keys.privateKey))),spki:b64(spki),cert:b64(cert)});
   try{localStorage.setItem(storeKey,encoded);need(localStorage.getItem(storeKey)===encoded,'저장 실패')}
   catch(_){throw Error('업데이트용 서명키를 저장하지 못했습니다. APK를 만들지 않았습니다.')}
   return {keys,spki,cert};
 }
 async function signApk(entries){let z=zip(entries),chunks=[];for(let a of[z.local,z.cd,z.e])for(let p=0;p<a.length;p+=1048576){let c=a.subarray(p,p+1048576);chunks.push(await digest(cat(Uint8Array.of(0xa5),L32(c.length),c)))}let dg=await digest(cat(Uint8Array.of(0x5a),L32(chunks.length),...chunks)),id=await identity(),signedData=cat(lp(lp(cat(L32(0x0103),lp(dg)))),lp(lp(id.cert)),lp(new Uint8Array(0))),sig=new Uint8Array(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',id.keys.privateKey,signedData)),signer=cat(lp(signedData),lp(lp(cat(L32(0x0103),lp(sig)))),lp(id.spki)),v2=lp(lp(signer)),pair=cat(L64(4+v2.length),L32(0x7109871a),v2),size=pair.length+24,block=cat(L64(size),pair,L64(size),enc.encode('APK Sig Block 42')),e=z.e.slice();e.set(L32(z.local.length+block.length),16);return cat(z.local,block,z.cd,e)}
 return{instantiate,extract,signApk,checksum,crc,hex,b64,unb64,cat,tables,digest,FPATH,EXPECTED,DEFAULTS,optionsFor};
})();
if(typeof module!=='undefined')module.exports=EdgeB;
