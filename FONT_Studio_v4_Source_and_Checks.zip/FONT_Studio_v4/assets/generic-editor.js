/* FONT Studio 4: real, local outline editing for ordinary fonts.
 * Paths are read with fontkit (including composite/CFF/CFF2/variable glyphs).
 * No glyph designs or fonts are bundled. Output is a static TrueType sfnt.
 * Synthetic thickness is a bounded geometric contour offset, not an optical master.
 */
'use strict';
const GenericEditor=(()=>{
 const FK=typeof FontkitLocal!=='undefined'?FontkitLocal:require('../vendor/fontkit-local.js');
 const F=()=>typeof FontStudio!=='undefined'?FontStudio:require('./font-studio.js');
 const E=()=>typeof EdgeB!=='undefined'?EdgeB:require('./engine.js');
 const need=(x,s)=>{if(!x)throw Error(s)},u16=(a,p)=>(a[p]<<8)|a[p+1],i16=(a,p)=>(u16(a,p)<<16)>>16,u32=(a,p)=>(a[p]*16777216+(a[p+1]<<16)+(a[p+2]<<8)+a[p+3])>>>0;
 const put16=(a,p,n)=>{n=Math.round(n);need(Number.isFinite(n)&&n>=-32768&&n<=65535,'폰트 좌표/크기가 저장 범위를 넘었습니다. 배율을 줄이세요.');a[p]=n>>>8&255;a[p+1]=n&255};
 const put32=(a,p,n)=>{a[p]=n>>>24;a[p+1]=n>>>16&255;a[p+2]=n>>>8&255;a[p+3]=n&255};
 const getFont=raw=>FK.create(raw instanceof Uint8Array?raw:new Uint8Array(raw));
 let cacheRaw=null,cacheFont=null;
 function fontFor(raw){if(cacheRaw!==raw){cacheRaw=raw;cacheFont=getFont(raw)}return cacheFont;}
 function inspect(raw){
  const p=F().parse(raw),axes={};const font=fontFor(raw);let reason='';
  for(const k of ['COLR','SVG ','sbix','CBDT','EBDT'])if(p.tables.has(k))reason='색상·비트맵 글꼴은 윤곽선 편집 대상이 아닙니다. 단색 TTF/OTF를 선택하세요.';
  const fv=font.variationAxes||{};for(const [k,a] of Object.entries(fv))axes[k]={min:a.min,max:a.max,default:a.default};
  // A changed variable instance with FeatureVariations needs a full feature instancer.
  // Do not silently apply default substitutions from a different axis position.
  for(const key of ['GSUB','GPOS']){const t=p.tables.get(key);if(t&&t.length>=14&&u32(t,0)===0x10001&&u32(t,10))reason='이 가변 폰트는 고급 FeatureVariations를 사용합니다. 일반 정적 TTF/OTF 버전을 선택하세요.';}
  const w=axes.wght;
  return{supported:!reason,reason,weightMode:w?'axis':'outline',weightMin:w?w.min:-15,weightMax:w?w.max:30,weightDefault:w?w.default:0,axes,
   defaults:{width:100,height:100,weight:w?w.default:0,spacing:0,leadingZero:false},
   notice:w?'원본 wght 축의 굵기를 확정한 뒤 가로·세로·간격을 적용합니다.':'두께 0은 원본입니다. −는 얇게, +는 두껍게 실제 윤곽선을 보정합니다. 과한 보정은 작은 구멍·얇은 획을 손상시킬 수 있습니다.'};
 }
 function options(raw,input){const cap=inspect(raw);need(cap.supported,cap.reason);const o={...cap.defaults,...input};
  for(const [key,min,max]of [['width',50,150],['height',60,140],['spacing',-10,20],['weight',cap.weightMin,cap.weightMax]])need(typeof o[key]==='number'&&Number.isFinite(o[key])&&o[key]>=min&&o[key]<=max,`${key}: ${min}~${max} 범위로 입력하세요.`);
  need(typeof o.leadingZero==='boolean','앞자리 0 옵션 오류');need(!o.leadingZero,'일반 폰트의 기존 치환 규칙을 보존하기 위해 앞자리 0은 OPPO 시계 모드에서만 지원합니다.');return o;
 }
 const midpoint=(a,b)=>[(a[0]+b[0])/2,(a[1]+b[1])/2];
 function pathsToContours(commands,tolerance){
  const contours=[];let c=null,at=[0,0],first=null;let budget=0;
  function point(x,y,on){need(Number.isFinite(x)&&Number.isFinite(y),'유효하지 않은 글리프 좌표입니다.');if(!c)c=[];c.push({x,y,on});need(++budget<65530,'복잡도가 너무 높은 글리프입니다.');}
  function close(){if(c&&c.length){if(c.length>1&&c[c.length-1].on&&c[0].x===c[c.length-1].x&&c[0].y===c[c.length-1].y)c.pop();if(c.length>1)contours.push(c)}c=null;}
  function cubic(p0,p1,p2,p3,depth=0){
   // Degree reduction error is bounded by the maximum control-point deviation.
   const q=[(3*(p1[0]+p2[0])-p0[0]-p3[0])/4,(3*(p1[1]+p2[1])-p0[1]-p3[1])/4];
   const c1=[p0[0]+2*(q[0]-p0[0])/3,p0[1]+2*(q[1]-p0[1])/3],c2=[p3[0]+2*(q[0]-p3[0])/3,p3[1]+2*(q[1]-p3[1])/3];
   const err=Math.max(Math.hypot(p1[0]-c1[0],p1[1]-c1[1]),Math.hypot(p2[0]-c2[0],p2[1]-c2[1]));
   if(err<=tolerance||depth>=12){point(q[0],q[1],false);point(p3[0],p3[1],true);return}
   const a=midpoint(p0,p1),b=midpoint(p1,p2),d=midpoint(p2,p3),e=midpoint(a,b),f=midpoint(b,d),m=midpoint(e,f);cubic(p0,a,e,m,depth+1);cubic(m,f,d,p3,depth+1);
  }
  for(const {command,args:a}of commands){switch(command){
   case'moveTo':close();at=[a[0],a[1]];first=at;point(...at,true);break;
   case'lineTo':point(a[0],a[1],true);at=[a[0],a[1]];break;
   case'quadraticCurveTo':point(a[0],a[1],false);point(a[2],a[3],true);at=[a[2],a[3]];break;
   case'bezierCurveTo':cubic(at,a.slice(0,2),a.slice(2,4),a.slice(4,6));at=a.slice(4,6);break;
   case'closePath':close();at=first||at;break;
   default:throw Error('지원하지 않는 윤곽선 명령: '+command);
  }}close();return contours;
 }
 function area(c){let a=0;for(let i=0;i<c.length;i++){const p=c[i],q=c[(i+1)%c.length];a+=p.x*q.y-q.x*p.y}return a/2;}
 function offsetContours(contours,delta){
  if(!delta)return contours;
  const total=contours.reduce((s,c)=>s+area(c),0);if(Math.abs(total)<1e-8)return contours;
  const sign=total<0?-1:1;
  return contours.map(c=>c.map((p,i)=>{
   let prev,next;for(let j=1;j<c.length;j++){const q=c[(i-j+c.length)%c.length];if(Math.hypot(p.x-q.x,p.y-q.y)>1e-7){prev=q;break}}
   for(let j=1;j<c.length;j++){const q=c[(i+j)%c.length];if(Math.hypot(q.x-p.x,q.y-p.y)>1e-7){next=q;break}}
   if(!prev||!next)return{...p};const li=Math.hypot(p.x-prev.x,p.y-prev.y),lo=Math.hypot(next.x-p.x,next.y-p.y);
   const ix=(p.x-prev.x)/li,iy=(p.y-prev.y)/li,ox=(next.x-p.x)/lo,oy=(next.y-p.y)/lo,d=1+ix*ox+iy*oy;
   if(d<.0625)return{...p};
   let nx=sign*(iy+oy),ny=-sign*(ix+ox),s=delta/d;
   // Bound miters and local folds; never change the topology or drop a glyph.
   const distance=Math.hypot(nx*s,ny*s),limit=Math.max(Math.abs(delta),Math.min(li,lo)*.75);
   if(distance>Math.max(Math.abs(delta)*4,limit))s*=Math.max(Math.abs(delta)*4,limit)/distance;
   return{x:p.x+nx*s,y:p.y+ny*s,on:p.on};
  }));
 }
 function glyphData(cs,sx,sy,shift){
  const contours=cs.map(c=>c.map(p=>({x:Math.round(p.x*sx+shift),y:Math.round(p.y*sy),on:p.on})));
  if(!contours.length)return{bytes:new Uint8Array(),bounds:[0,0,0,0],points:0,contours:0};
  const pts=contours.flat(),n=pts.length;need(n>0&&n<65535&&contours.length<32768,'글리프 크기가 너무 큽니다.');
  let xmin=Infinity,ymin=Infinity,xmax=-Infinity,ymax=-Infinity;
  for(const p of pts){xmin=Math.min(xmin,p.x);ymin=Math.min(ymin,p.y);xmax=Math.max(xmax,p.x);ymax=Math.max(ymax,p.y)}
  for(const v of [xmin,ymin,xmax,ymax])need(v>=-32768&&v<=32767,'글자 범위가 너무 큽니다. 가로·세로 배율을 줄이세요.');
  const b=new Uint8Array(12+2*contours.length+n*5);[contours.length,xmin,ymin,xmax,ymax].forEach((v,i)=>put16(b,2*i,v));
  let e=-1;contours.forEach((c,i)=>{e+=c.length;put16(b,10+2*i,e)});const flags=12+2*contours.length,xpos=flags+n,ypos=xpos+2*n;let px=0,py=0;
  pts.forEach((p,i)=>{b[flags+i]=p.on?1:0;const dx=p.x-px,dy=p.y-py;need(dx>=-32768&&dx<=32767&&dy>=-32768&&dy<=32767,'글리프 좌표 차가 너무 큽니다.');put16(b,xpos+2*i,dx);put16(b,ypos+2*i,dy);px=p.x;py=p.y});
  return{bytes:b,bounds:[xmin,ymin,xmax,ymax],points:n,contours:contours.length};
 }
 function scaleLayout(tables,sx,sy,font){
  // Standard GPOS 1-9. Relative lookup offsets remain intact; point anchors are
  // converted to coordinate anchors after decomposing outlines; hint devices dropped.
  const b=tables.get('GPOS');const touched=new Set();const bound=(p,n=2)=>need(p>=0&&p+n<=b.length,'GPOS 구조가 손상되어 편집을 중단했습니다.');
  const val=(p,scale)=>{bound(p);if(!touched.has(p)){put16(b,p,Math.round(i16(b,p)*scale));touched.add(p)}};
  let store=null;try{store=font.GDEF&&font.GDEF.itemVariationStore}catch(_){}
  function delta(base,off){if(!off)return 0;const p=base+off;bound(p,6);if(u16(b,p+4)!==0x8000||!store||!font._variationProcessor)return 0;return font._variationProcessor.getDelta(store,u16(b,p),u16(b,p+2));}
  function values(p,fmt,base){const fields={};need(!(fmt&0xff00),'미지원 GPOS 값 형식');for(let k=0;k<8;k++)if(fmt&(1<<k)){bound(p);fields[k]=p;p+=2}
   for(let k=0;k<4;k++){const q=fields[k],dev=fields[k+4];if(q!==undefined&&!touched.has(q)){const d=dev!==undefined?delta(base,u16(b,dev)):0;put16(b,q,Math.round((i16(b,q)+d)*(k%2?sy:sx)));touched.add(q)}else if(q===undefined&&dev!==undefined&&delta(base,u16(b,dev))!==0)throw Error('이 가변 폰트의 GPOS 보정 형식은 현재 지원하지 않습니다. 정적 버전을 사용하세요.');if(dev!==undefined)put16(b,dev,0)}return p;
  }
  const anchors=new Set();function anchor(base,off){if(!off)return;const p=base+off;if(anchors.has(p))return;anchors.add(p);bound(p,6);const fmt=u16(b,p);need([1,2,3].includes(fmt),'알 수 없는 GPOS 앵커');let dx=0,dy=0;if(fmt===3){bound(p,10);dx=delta(p,u16(b,p+6));dy=delta(p,u16(b,p+8))}put16(b,p+2,Math.round((i16(b,p+2)+dx)*sx));put16(b,p+4,Math.round((i16(b,p+4)+dy)*sy));put16(b,p,1);}
  function markArray(base){bound(base);const n=u16(b,base);bound(base+2,n*4);for(let i=0;i<n;i++)anchor(base,u16(b,base+4+4*i));}
  function baseArray(base,classes){bound(base);const n=u16(b,base);need(classes*n<200000,'GPOS 앵커 제한');bound(base+2,n*classes*2);for(let i=0;i<n*classes;i++)anchor(base,u16(b,base+2+2*i));}
  const seen=new Set();function sub(type,p,depth=0){bound(p,2);need(depth<8,'GPOS 확장 재귀 오류');const key=type+':'+p;if(seen.has(key))return;seen.add(key);const fmt=u16(b,p);
   if(type===1){bound(p,6);const vf=u16(b,p+4);if(fmt===1)values(p+6,vf,p);else{need(fmt===2,'GPOS Single 형식 오류');bound(p+6);let q=p+8,n=u16(b,p+6);for(let i=0;i<n;i++)q=values(q,vf,p)}}
   else if(type===2){bound(p,10);const f1=u16(b,p+4),f2=u16(b,p+6);if(fmt===1){const n=u16(b,p+8);bound(p+10,n*2);for(let i=0;i<n;i++){const s=p+u16(b,p+10+2*i);bound(s);const m=u16(b,s);let q=s+2;for(let j=0;j<m;j++){bound(q);q=values(q+2,f1,s);q=values(q,f2,s)}}}else{need(fmt===2,'GPOS Pair 형식 오류');bound(p,16);const n=u16(b,p+12)*u16(b,p+14);need(n<1000000,'GPOS Pair 클래스 제한');let q=p+16;for(let i=0;i<n;i++){q=values(q,f1,p);q=values(q,f2,p)}}}
   else if(type===3){need(fmt===1,'GPOS Cursive 형식 오류');bound(p,6);const n=u16(b,p+4);bound(p+6,n*4);for(let i=0;i<n;i++){anchor(p,u16(b,p+6+4*i));anchor(p,u16(b,p+8+4*i))}}
   else if([4,5,6].includes(type)){need(fmt===1,'GPOS Mark 형식 오류');bound(p,12);const classes=u16(b,p+6),m=p+u16(b,p+8),base=p+u16(b,p+10);markArray(m);if(type!==5)baseArray(base,classes);else{bound(base);const n=u16(b,base);bound(base+2,n*2);for(let i=0;i<n;i++){const a=base+u16(b,base+2+2*i);baseArray(a,classes)}}}
   else if(type===9){need(fmt===1,'GPOS Extension 형식 오류');bound(p,8);sub(u16(b,p+2),p+u32(b,p+4),depth+1)}
   else need(type===7||type===8,'지원하지 않는 GPOS 조회 형식');
  }
  if(b){bound(0,10);const at=u16(b,8);bound(at);const n=u16(b,at);bound(at+2,n*2);for(let i=0;i<n;i++){const l=at+u16(b,at+2+2*i);bound(l,6);const type=u16(b,l),m=u16(b,l+4);bound(l+6,m*2);for(let j=0;j<m;j++)sub(type,l+u16(b,l+6+2*j));}}
  const kern=tables.get('kern');if(kern&&u16(kern,0)===0){let p=4;const n=u16(kern,2);for(let i=0;i<n;i++){need(p+6<=kern.length,'kern 범위 오류');const len=u16(kern,p+2),coverage=u16(kern,p+4);need(len>=6&&p+len<=kern.length,'kern 길이 오류');if((coverage>>>8)===0){const cnt=u16(kern,p+6);need(p+14+6*cnt<=p+len,'kern 값 오류');for(let j=0;j<cnt;j++)put16(kern,p+18+j*6,Math.round(i16(kern,p+18+j*6)*(coverage&1?sx:sy)))}p+=len}}
  const gd=tables.get('GDEF');if(gd&&gd.length>=12){put16(gd,6,0);const lc=u16(gd,8);if(lc&&lc+4<=gd.length){const n=u16(gd,lc+2);for(let i=0;i<n;i++){const lig=lc+u16(gd,lc+4+2*i);if(lig+2>gd.length)break;const count=u16(gd,lig);for(let j=0;j<count;j++){const cp=lig+u16(gd,lig+2+2*j);if(cp+4>gd.length)break;const fmt=u16(gd,cp);if(fmt===1||fmt===3){put16(gd,cp,1);put16(gd,cp+2,Math.round(i16(gd,cp+2)*sx))}else if(fmt===2)put16(gd,8,0);}}}}
 }
 async function edit(raw,input={},hooks={}){
  const cap=inspect(raw),o=options(raw,input),p=F().parse(raw);need(cap.supported,cap.reason);
  if(o.width===100&&o.height===100&&o.weight===cap.weightDefault&&o.spacing===0&&!p.tables.has('fvar'))return raw.slice();
  const sx=o.width/100,sy=o.height/100,tracking=p.upm*o.spacing/100,amount=cap.weightMode==='outline'?o.weight*p.upm/1000:0;
  let font=fontFor(raw);if(p.tables.has('fvar')){const axis={};for(const[k,a]of Object.entries(cap.axes))axis[k]=k==='wght'?o.weight:a.default;font=font.getVariation(axis)}
  // Memoize varied TrueType contours per instance. Composite glyph reuse must
  // not apply phantom-point deltas to a glyph's already-varied metrics twice.
  if(p.tables.has('gvar')){const get=font.getGlyph.bind(font);font.getGlyph=(...args)=>{const g=get(...args);if(g.type==='TTF'&&!g._studioContoursMemo){const fn=g._getContours;let cache=null;g._getContours=function(){return cache||(cache=fn.call(this))};g._studioContoursMemo=true;}return g;};}
  const blobs=[],loca=new Uint8Array(4*(p.glyphs+1)),hmtx=new Uint8Array(4*p.glyphs),vmtx=p.tables.has('vmtx')?new Uint8Array(4*p.glyphs):null;
  let total=0,maxPoints=0,maxContours=0,maxAdv=0,minL=32767,minR=32767,maxExt=-32768,bounds=[32767,32767,-32768,-32768];
  for(let gid=0;gid<p.glyphs;gid++){
   if(gid%64===0){if(hooks.cancelled&&hooks.cancelled())throw Error('CANCELLED');if(hooks.progress)hooks.progress(gid,p.glyphs);await new Promise(r=>setTimeout(r,0))}
   let g=font.getGlyph(gid),commands;try{commands=g.path.commands}catch(e){throw Error(`글리프 ${gid}를 읽지 못했습니다: ${e.message}`)}
   let cs=pathsToContours(commands,Math.max(.08,p.upm/8000));
   const oldX=cs.length?Math.min(...cs.flat().map(p=>p.x)):0;
   cs=offsetContours(cs,amount);
   // Normalize CFF clockwise orientation for TrueType without changing fill.
   if(cs.reduce((s,c)=>s+area(c),0)>0)cs=cs.map(c=>c.slice().reverse());
   const metrics=g._getMetrics(),adv0=metrics.advanceWidth;const track=adv0>0&&gid>0?tracking:0;
   const gd=glyphData(cs,sx,sy,track/2);const aw=Math.round(adv0*sx+track+(amount>0?2*amount*sx:0));
   need(aw>=0&&aw<=65535,`글리프 ${gid}의 배치 폭이 음수 또는 너무 큽니다. 간격/배율을 줄이세요.`);
   // CFF side bearings are derived from outlines, not the default hmtx bearing.
   // In particular CFF2 variation changes xmin while hmtx may keep its default.
   // Variable TrueType specifies origin-aligned lsb=xmin for each instance (head spec).
   const lsb=gd.points?(p.tables.has('glyf')&&!p.tables.has('fvar')?Math.round(metrics.leftBearing*sx+(gd.bounds[0]-oldX*sx)):gd.bounds[0]):0;
   need(lsb>=-32768&&lsb<=32767,'글리프 좌측 여백이 범위를 넘습니다.');
   put16(hmtx,4*gid,aw);put16(hmtx,4*gid+2,lsb);put32(loca,4*gid,total);blobs.push(gd.bytes);total+=gd.bytes.length;
   const pad=(4-total%4)%4;if(pad){blobs.push(new Uint8Array(pad));total+=pad}need(total<=F().MAX_FONT,'변환한 글리프가 24 MB를 초과합니다.');
   if(vmtx){put16(vmtx,gid*4,Math.max(0,Math.min(65535,Math.round(metrics.advanceHeight*sy))));put16(vmtx,gid*4+2,Math.round(metrics.topBearing*sy));}
   maxAdv=Math.max(maxAdv,aw);minL=Math.min(minL,lsb);minR=Math.min(minR,aw-lsb-(gd.bounds[2]-gd.bounds[0]));maxExt=Math.max(maxExt,lsb+gd.bounds[2]-gd.bounds[0]);
   maxPoints=Math.max(maxPoints,gd.points);maxContours=Math.max(maxContours,gd.contours);
   if(gd.points){bounds[0]=Math.min(bounds[0],gd.bounds[0]);bounds[1]=Math.min(bounds[1],gd.bounds[1]);bounds[2]=Math.max(bounds[2],gd.bounds[2]);bounds[3]=Math.max(bounds[3],gd.bounds[3]);}
  }
  put32(loca,4*p.glyphs,total);const t=p.tables;
  for(const k of ['CFF ','CFF2','VORG','fvar','gvar','cvar','avar','HVAR','VVAR','MVAR','STAT','DSIG','fpgm','prep','cvt ','hdmx','LTSH','VDMX','gasp','BASE','JSTF','MATH'])t.delete(k);
  // Point-based/hinted auxiliary data cannot describe newly decomposed outlines.
  t.set('glyf',E().cat(...blobs));t.set('loca',loca);t.set('hmtx',hmtx);if(vmtx)t.set('vmtx',vmtx);
  const maxp=new Uint8Array(32);put32(maxp,0,0x10000);put16(maxp,4,p.glyphs);put16(maxp,6,maxPoints);put16(maxp,8,maxContours);put16(maxp,14,1);t.set('maxp',maxp);
  const head=t.get('head');put16(head,50,1);for(let i=0;i<4;i++)put16(head,36+2*i,bounds[i]);put16(head,16,u16(head,16)&~(1<<4));
  const hh=t.get('hhea');put16(hh,4,Math.max(Math.round(i16(hh,4)*sy),bounds[3]));put16(hh,6,Math.min(Math.round(i16(hh,6)*sy),bounds[1]));put16(hh,8,Math.round(i16(hh,8)*sy));put16(hh,10,maxAdv);put16(hh,12,minL);put16(hh,14,minR);put16(hh,16,maxExt);put16(hh,34,p.glyphs);
  const vh=t.get('vhea');if(vh&&vmtx){put16(vh,34,p.glyphs);for(const off of [4,6,8,12,14,16])put16(vh,off,Math.round(i16(vh,off)*sx));put16(vh,10,Math.round(u16(vh,10)*sy))}
  const os=t.get('OS/2');if(os){if(os.length>=78){put16(os,2,Math.round(i16(os,2)*sx));for(const off of [10,14,18,22])put16(os,off,Math.round(i16(os,off)*sx));for(const off of [12,16,20,24,26,28])put16(os,off,Math.round(i16(os,off)*sy));for(const off of [68,70,72])put16(os,off,Math.round(i16(os,off)*sy));put16(os,74,Math.max(0,bounds[3],Math.round(u16(os,74)*sy)));put16(os,76,Math.max(0,-bounds[1],Math.round(u16(os,76)*sy)))}
   if(os.length>=96)for(const off of [86,88])put16(os,off,Math.round(i16(os,off)*sy));if(cap.weightMode==='axis')put16(os,4,Math.max(1,Math.min(1000,Math.round(o.weight))));
  }
  let post=t.get('post');if(post&&post.length>=32){post=post.slice(0,32);put32(post,0,0x30000);put16(post,8,Math.round(i16(post,8)*sy));put16(post,10,Math.round(i16(post,10)*sy));t.set('post',post)}
  scaleLayout(t,sx,sy,font);
  if(hooks.cancelled&&hooks.cancelled())throw Error('CANCELLED');if(hooks.progress)hooks.progress(p.glyphs,p.glyphs);
  return F().assemble(t,0x10000);
 }
 return{inspect,options,edit,pathsToContours,offsetContours};
})();
if(typeof module!=='undefined')module.exports=GenericEditor;
